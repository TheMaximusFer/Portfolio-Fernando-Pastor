package es.unizar.eina.T221_quads.database;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serial;
import java.io.Serializable;

/** Clase anotada como entidad que representa un quad y que consta de matrícula, tipo, precio y
 *  descripción. */
@Entity(tableName = "quad")
public class Quad implements Serializable {
    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "matricula")
    private String matricula;

    @NonNull
    @ColumnInfo(name = "tipo")
    private String tipo;

    @ColumnInfo(name = "precio")
    private double precio;

    @ColumnInfo(name = "descripcion")
    private String descripcion;

    @Serial
    private static final long serialVersionUID = 1L;

    public Quad(@NonNull String matricula, @NonNull String tipo, double precio, String descripcion) {
        this.matricula = matricula;
        this.tipo = tipo;
        this.precio = precio;
        this.descripcion = descripcion;
    }

    /** Devuelve la matrícula del quad */
    @NonNull
    public String getMatricula(){ return this.matricula; }

    /** Permite actualizar la matrícula del quad */
    public void setMatricula(@NonNull String matricula) { this.matricula = matricula; }

    /** Devuelve el tipo del quad */
    @NonNull
    public String getTipo(){ return this.tipo;}

    /** Permite actualizar el tipo del quad */
    public void setTipo(@NonNull String tipo) { this.tipo = tipo; }

    /** Devuelve el precio del quad */
    public double getPrecio(){ return this.precio; }

    /** Permite actualizar el precio del quad */
    public void setPrecio(double precio) { this.precio = precio; }

    /** Devuelve la descripción del quad */
    public String getDescripcion(){
        return this.descripcion;
    }

    /** Permite actualizar la descripción del quad */
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
