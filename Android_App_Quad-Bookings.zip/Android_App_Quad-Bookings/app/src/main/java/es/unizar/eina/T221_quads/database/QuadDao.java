package es.unizar.eina.T221_quads.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.Date;
import java.util.List;

/** Definición de un Data Access Object para los quads */
@Dao
public interface QuadDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(Quad quad);

    @Update
    int update(Quad quad);

    @Delete
    int delete(Quad quad);

    @Query("DELETE FROM quad")
    void deleteAll();

    @Query("SELECT * FROM quad WHERE matricula IN (:matriculas)")
    LiveData<List<Quad>> getQuadsByMatriculas(List<String> matriculas);

    @Query("SELECT * FROM quad ORDER BY matricula ASC")
    LiveData<List<Quad>> getOrderedQuadsByMatriculaAsc();

    @Query("SELECT * FROM quad ORDER BY matricula DESC")
    LiveData<List<Quad>> getOrderedQuadsByMatriculaDesc();

    @Query("SELECT * FROM quad ORDER BY tipo ASC")
    LiveData<List<Quad>> getOrderedQuadsByTipoAsc();

    @Query("SELECT * FROM quad ORDER BY tipo DESC")
    LiveData<List<Quad>> getOrderedQuadsByTipoDesc();

    @Query("SELECT * FROM quad ORDER BY precio ASC")
    LiveData<List<Quad>> getOrderedQuadsByPrecioAsc();

    @Query("SELECT * FROM quad ORDER BY precio DESC")
    LiveData<List<Quad>> getOrderedQuadsByPrecioDesc();

    /** Verifica si existe un quad con la matrícula especificada */
    @Query("SELECT COUNT(*) > 0 FROM quad WHERE matricula = :matricula")
    boolean exists(String matricula);

    /** Obtiene los quads disponibles en un rango de fechas (no reservados en ese período)
     * @param fechaInicio Fecha de inicio del rango
     * @param fechaFin Fecha de fin del rango
     * @param excluirReservaId ID de reserva a excluir (útil al editar una reserva existente). Usar -1 para no excluir ninguna
     */
    @Query("SELECT DISTINCT q.* FROM quad q " +
           "WHERE q.matricula NOT IN (" +
           "    SELECT DISTINCT rq.quad_matricula " +
           "    FROM reserva_quad rq " +
           "    INNER JOIN reserva r ON rq.reserva_id = r.id " +
           "    WHERE (r.fechaRecogida <= :fechaFin AND r.fechaDevolucion >= :fechaInicio) " +
           "    AND (:excluirReservaId = -1 OR r.id != :excluirReservaId)" +
           ") " +
           "ORDER BY q.matricula ASC")
    LiveData<List<Quad>> getQuadsDisponibles(Date fechaInicio, Date fechaFin, int excluirReservaId);
}