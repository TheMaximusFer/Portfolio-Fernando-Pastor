package es.unizar.eina.T221_quads.database;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Date;

/** Clase anotada como entidad que representa una reserva y que consta de id, nombreCliente,
 *  telefonoCliente, fechaRecogida, fechaDevolucion y precioTotal. */
@Entity(tableName = "reserva")
public class Reserva implements Serializable {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;

    @NonNull
    @ColumnInfo(name = "nombreCliente")
    private String nombreCliente;

    @NonNull
    @ColumnInfo(name = "telefonoCliente")
    private String telefonoCliente;

    @NonNull
    @ColumnInfo(name = "fechaRecogida")
    private Date fechaRecogida;

    @NonNull
    @ColumnInfo(name = "fechaDevolucion")
    private Date fechaDevolucion;

    @ColumnInfo(name = "precioTotal")
    private double precioTotal;

    /**
     * Resumen textual de los quads asociados a la reserva (dato calculado / no persistente).
     * Se marca con @Ignore para no afectar al esquema Room.
     */
    @Ignore
    private String resumenQuads;

    public Reserva(@NonNull String nombreCliente, @NonNull String telefonoCliente,
                   @NonNull Date fechaRecogida, @NonNull Date fechaDevolucion, double precioTotal) {
        this.nombreCliente = nombreCliente;
        this.telefonoCliente = telefonoCliente;
        this.fechaRecogida = fechaRecogida;
        this.fechaDevolucion = fechaDevolucion;
        this.precioTotal = precioTotal;
        this.resumenQuads = "";
    }

    /** Devuelve el identificador de la reserva */
    public int getId(){
        return this.id;
    }

    /** Permite actualizar el identificador de una reserva */
    public void setId(int id) {
        this.id = id;
    }

    /** Devuelve el nombre del cliente asociado a la reserva */
    @NonNull
    public String getNombreCliente(){
        return this.nombreCliente;
    }

    /** Permite actualizar el nombre del cliente asociado a la reserva */
    public void setNombreCliente(@NonNull String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    /** Devuelve el teléfono del cliente asociado a la reserva */
    @NonNull
    public String getTelefonoCliente(){
        return this.telefonoCliente;
    }

    /** Permite actualizar el teléfono del cliente asociado a la reserva */
    public void setTelefonoCliente(@NonNull String telefonoCliente) {
        this.telefonoCliente = telefonoCliente;
    }

    public String getTelefonoFormateado() {
        return getTelefonoCliente().replaceAll("\\s+", "");
    }

    /** Devuelve la fecha de recogida de la reserva */
    @NonNull
    public Date getFechaRecogida(){ return this.fechaRecogida; }

    /** Permite actualizar la fecha de recogida de la reserva */
    public void setFechaRecogida(@NonNull Date fechaRecogida) { this.fechaRecogida = fechaRecogida; }

    /** Devuelve la fecha de devolución de la reserva */
    @NonNull
    public Date getFechaDevolucion(){ return this.fechaDevolucion; }

    /** Permite actualizar la fecha de devolución de la reserva */
    public void setFechaDevolucion(@NonNull Date fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }

    public String getFechasFormateadas() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        return sdf.format(fechaRecogida) + " — " + sdf.format(fechaDevolucion);
    }

    /** Devuelve el precio total de la reserva */
    public double getPrecioTotal(){ return this.precioTotal; }

    /** Permite actualizar el precio total de la reserva */
    public void setPrecioTotal(double precioTotal) { this.precioTotal = precioTotal; }

    /**
     * Devuelve un resumen (no persistente) de los quads asociados a la reserva.
     * Nota: este valor debe ser rellenado por la capa UI/VM cuando se carguen los quads.
     */
    public String getResumenQuads() {
        return (resumenQuads == null) ? "" : resumenQuads;
    }

    /** Permite actualizar el resumen (no persistente) de quads asociados a la reserva. */
    public void setResumenQuads(String resumenQuads) {
        this.resumenQuads = resumenQuads;
    }
}
