package es.unizar.eina.T221_quads.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.Date;
import java.util.List;

/** Definición de un Data Access Object para las reservas */
@Dao
public interface ReservaDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(Reserva reserva);

    @Update
    int update(Reserva reserva);

    @Delete
    int delete(Reserva reserva);

    /** Obtiene la lista de matrículas de quads para un ID de reserva concreto */
    @Query("SELECT quad_matricula FROM reserva_quad WHERE reserva_id = :reservaId")
    LiveData<List<String>> getMatriculasForReserva(int reservaId);


    @Query("DELETE FROM reserva")
    void deleteAll();

    @Query("SELECT * FROM reserva ORDER BY nombreCliente ASC")
    LiveData<List<Reserva>> getOrderedReservasByNombreClienteAsc();

    @Query("SELECT * FROM reserva ORDER BY nombreCliente DESC")
    LiveData<List<Reserva>> getOrderedReservasByNombreClienteDesc();

    @Query("SELECT * FROM reserva ORDER BY telefonoCliente ASC")
    LiveData<List<Reserva>> getOrderedReservasByTelefonoClienteAsc();

    @Query("SELECT * FROM reserva ORDER BY telefonoCliente DESC")
    LiveData<List<Reserva>> getOrderedReservasByTelefonoClienteDesc();

    @Query("SELECT * FROM reserva ORDER BY fechaRecogida ASC")
    LiveData<List<Reserva>> getOrderedReservasByFechaRecogidaAsc();

    @Query("SELECT * FROM reserva ORDER BY fechaRecogida DESC")
    LiveData<List<Reserva>> getOrderedReservasByFechaRecogidaDesc();

    @Query("SELECT * FROM reserva ORDER BY fechaDevolucion ASC")
    LiveData<List<Reserva>> getOrderedReservasByFechaDevolucionAsc();

    @Query("SELECT * FROM reserva ORDER BY fechaDevolucion DESC")
    LiveData<List<Reserva>> getOrderedReservasByFechaDevolucionDesc();

    /** Obtener reservas por rango de fechas (para ver disponibilidad) */
    @Query("SELECT * FROM reserva WHERE (:fechaInicio BETWEEN fechaRecogida AND fechaDevolucion) " +
            "OR (:fechaFin BETWEEN fechaRecogida AND fechaDevolucion) OR " +
            "(fechaRecogida BETWEEN :fechaInicio AND :fechaFin)")
    LiveData<List<Reserva>> getReservasEnRango(Date fechaInicio, Date fechaFin);

    /** Verifica si existe una reserva con el ID especificado */
    @Query("SELECT COUNT(*) > 0 FROM reserva WHERE id = :id")
    boolean exists(int id);
}