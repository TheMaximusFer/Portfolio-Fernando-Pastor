package es.unizar.eina.T221_quads.database;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;

/** Clase anotada como entidad que representa la relación entre reservas y quads y que consta de
 *  la matrícula del quad (quadMatricula), el id de la reserva (reservaId) y el número de cascos
 *  necesarios para dicha reclación (numCascos). */
@Entity(tableName = "reserva_quad",
        primaryKeys = {"quad_matricula", "reserva_id"},
        foreignKeys = {
                @ForeignKey(
                        entity = Quad.class,
                        parentColumns = "matricula",
                        childColumns = "quad_matricula",
                        onDelete = ForeignKey.CASCADE
                ),
                @ForeignKey(
                        entity = Reserva.class,
                        parentColumns = "id",
                        childColumns = "reserva_id",
                        onDelete = ForeignKey.CASCADE
                )
        },
        indices = {
                @Index("quad_matricula"),
                @Index("reserva_id")
        }
)
public class ReservaQuad {
    @NonNull
    @ColumnInfo(name = "quad_matricula")
    private String quadMatricula;

    @ColumnInfo(name = "reserva_id")
    private int reservaId;

    @ColumnInfo(name = "num_cascos")
    private int numCascos;

    public ReservaQuad(@NonNull String quadMatricula, int reservaId, int numCascos) {
        this.quadMatricula = quadMatricula;
        this.reservaId = reservaId;
        this.numCascos = numCascos;
    }

    /** Devuelve la matrícula del quad */
    @NonNull
    public String getQuadMatricula(){ return this.quadMatricula; }

    /** Establece la matrícula del quad */
    public void setQuadMatricula(@NonNull String quadMatricula) { this.quadMatricula = quadMatricula; }

    /** Devuelve el id de la reserva */
    public int getReservaId(){ return this.reservaId; }

    /** Establece el id de la reserva */
    public void setReservaId(int reservaId) { this.reservaId = reservaId; }

    /** Devuelve el número de cascos del quad */
    public int getNumCascos(){ return this.numCascos; }

    /** Establece el número de cascos del quad */
    public void setNumCascos(int numCascos) { this.numCascos = numCascos; }
}
