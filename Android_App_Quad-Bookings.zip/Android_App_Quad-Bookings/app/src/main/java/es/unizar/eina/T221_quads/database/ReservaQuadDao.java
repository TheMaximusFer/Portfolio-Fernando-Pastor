package es.unizar.eina.T221_quads.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

/** Definición de un Data Access Object para la relación entre reservas y quads.*/
@Dao
public interface ReservaQuadDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(ReservaQuad reservaQuad);

    @Update
    int update(ReservaQuad reservaQuad);

    @Delete
    int delete(ReservaQuad reservaQuad);

    @Query("DELETE FROM reserva_quad")
    void deleteAll();

    /** Obtener todos los quads de una reserva específica */
    @Query("SELECT q.* FROM quad q INNER JOIN reserva_quad rq ON q.matricula = rq.quad_matricula " +
            "WHERE rq.reserva_id = :reservaId")
    LiveData<List<Quad>> getQuadsByReserva(int reservaId);

    /** Obtener todas las reservas de un quad específico */
    @Query("SELECT r.* FROM reserva r INNER JOIN reserva_quad rq ON r.id = rq.reserva_id " +
            "WHERE rq.quad_matricula = :quadMatricula")
    LiveData<List<Reserva>> getReservasByQuad(String quadMatricula);

    /** Obtener el número de cascos para un quad en una reserva */
    @Query("SELECT num_cascos FROM reserva_quad WHERE reserva_id = :reservaId" +
            " AND quad_matricula = :quadMatricula")
    int getNumCascos(int reservaId, String quadMatricula);

    /** Eliminar todos los quads de una reserva específica */
    @Query("DELETE FROM reserva_quad WHERE reserva_id = :reservaId")
    int deleteQuadsFromReserva(int reservaId);

    /** Eliminar un quad específico de una reserva específica. */
    @Query("DELETE FROM reserva_quad WHERE quad_matricula = :quadMatricula " +
            "AND reserva_id = :reservaId")
    int deleteQuadFromReserva(String quadMatricula, int reservaId);
}