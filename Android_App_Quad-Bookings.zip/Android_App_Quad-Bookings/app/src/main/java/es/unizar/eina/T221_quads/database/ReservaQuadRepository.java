package es.unizar.eina.T221_quads.database;


import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Clase que gestiona el acceso la fuente de datos.
 * Interacciona con la base de datos a través de las clases ReservaQuadsRoomDatabase y ReservaQuadDao.
 */
public class ReservaQuadRepository {

    private final ReservaQuadDao mReservaQuadDao;

    private final long TIMEOUT = 15000;

    /**
     * Constructor de ReservaQuadRepository utilizando el contexto de la aplicación para instanciar la base de datos.
     * Alternativamente, se podría estudiar la instanciación del repositorio con una referencia a la base de datos
     * siguiendo el ejemplo de
     * <a href="https://github.com/android/architecture-components-samples/blob/main/BasicSample/app/src/main/java/com/example/android/persistence/DataRepository.java">architecture-components-samples/.../persistence/DataRepository</a>
     */
    public ReservaQuadRepository(Application application) {
        ReservaQuadsRoomDatabase db = ReservaQuadsRoomDatabase.getDatabase(application);
        mReservaQuadDao = db.reservaQuadDao();
    }

    /** Obtener todos los quads de una reserva específica */
    public LiveData<List<Quad>> getQuadsByReserva(int reservaId) {
        return mReservaQuadDao.getQuadsByReserva(reservaId);
    }

    /** Obtener todas las reservas de un quad específico */
    public LiveData<List<Reserva>> getReservasByQuad(String quadMatricula) {
        return mReservaQuadDao.getReservasByQuad(quadMatricula);
    }

    /** Obtener el número de cascos para un quad en una reserva */
    public int getNumCascos(int reservaId, String quadMatricula) {
        Future<Integer> future = ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaQuadDao.getNumCascos(reservaId, quadMatricula));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaQuadRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }

    /** Eliminar todos los quads de una reserva específica */
    public int deleteQuadsFromReserva(int reservaId) {
        Future<Integer> future = ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaQuadDao.deleteQuadsFromReserva(reservaId));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaQuadRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }

    /** Eliminar un quad específico de una reserva */
    public int deleteQuadFromReserva(String quadMatricula, int reservaId) {
        Future<Integer> future = ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaQuadDao.deleteQuadFromReserva(quadMatricula, reservaId));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaQuadRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }

    /** Inserta una relación entre reserva y quad nueva en la base de datos.
     * @param reservaQuad El quad consta de: un título (note.getTitle()) no nulo (note.getTitle()!=null) y no vacío
     *             (note.getTitle().length()>0); y un cuerpo (note.getBody()) no nulo.
     * @return Si el quad se ha insertado correctamente, devuelve el identificador del quad que se ha creado. En caso
     *         contrario, devuelve -1 para indicar el fallo.
     */
    public long insert(ReservaQuad reservaQuad) {
        /* Para que la App funcione correctamente y no lance una excepción, la modificación de la
         * base de datos se debe lanzar en un hilo de ejecución separado
         * (databaseWriteExecutor.submit). Para poder sincronizar la recuperación del resultado
         * devuelto por la base de datos, se puede utilizar un Future.
         */
        Future<Long> future = ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaQuadDao.insert(reservaQuad));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaQuadRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }

    /** Actualiza un quad en la base de datos
     * @param reservaQuad El quad que se desea actualizar y que consta de: un identificador
     *             (quad.getMatricula()) mayor que 0; un título (note.getTitle()) no nulo y no vacío;
     *             y un cuerpo (note.getBody()) no nulo.
     * @return Un valor entero con el número de filas modificadas; -1 si no existe previamente un quad con
     *         ese identificador, o hay algún problema con los atributos.
     */
    public int update(ReservaQuad reservaQuad) {
        Future<Integer> future = ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaQuadDao.update(reservaQuad));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaQuadRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }


    /** Elimina un quad en la base de datos.
     * @param reservaQuad Objeto quad cuyo atributo identificador (note.getId()) contiene la clave primaria del quad que se
     *             va a eliminar de la base de datos. Se debe cumplir: note.getId() > 0.
     * @return Un valor entero con el número de filas eliminadas: 1 si el identificador se corresponde con un quad
     *         previamente insertada; 0 si no existe previamente un quad con ese identificador o el identificador no es
     *         un valor aceptable.
     */
    public int delete(ReservaQuad reservaQuad) {
        Future<Integer> future = ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaQuadDao.delete(reservaQuad));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaQuadRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }
}
