package es.unizar.eina.T221_quads.database;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Quad.class, Reserva.class, ReservaQuad.class},
        version = 1, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class ReservaQuadsRoomDatabase extends RoomDatabase {

    public abstract QuadDao quadDao();
    public abstract ReservaDao reservaDao();
    public abstract ReservaQuadDao reservaQuadDao();

    private static volatile ReservaQuadsRoomDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static ReservaQuadsRoomDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (ReservaQuadsRoomDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    ReservaQuadsRoomDatabase.class, "reservaQuads_database_2")
                            .addCallback(sRoomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static final RoomDatabase.Callback sRoomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);

            databaseWriteExecutor.execute(() -> {
                /* Obtener todos los DAOs
                QuadDao quadDao = INSTANCE.quadDao();
                ReservaDao reservaDao = INSTANCE.reservaDao();
                ReservaQuadDao reservaQuadDao = INSTANCE.reservaQuadDao();

                // Limpiar todas las tablas
                quadDao.deleteAll();
                reservaDao.deleteAll();
                reservaQuadDao.deleteAll();

                // 1. INSERTAR QUADS DE PRUEBA
                Quad quad1 = new Quad("1234ABC", "Biplaza", 50.0, "Quad biplaza con 300cc");
                quadDao.insert(quad1);

                Quad quad2 = new Quad("5678DEF", "Monoplaza", 25.0, "Quad monoplaza con 50cc");
                quadDao.insert(quad2);

                Quad quad3 = new Quad("9012GHI", "Biplaza", 40.0, "Quad para 2 personas");
                quadDao.insert(quad3);

                Quad quad4 = new Quad("3456JKL", "Monoplaza", 60.0, "Quad monoplaza con 450cc");
                quadDao.insert(quad4);

                Quad quad5 = new Quad("3456JKL", "Monoplaza", 60.0, "Quad monoplaza con 450cc");
                quadDao.insert(quad5);

                Quad quad6 = new Quad("3456JKL", "Monoplaza", 60.0, "Quad monoplaza con 450cc");
                quadDao.insert(quad6);

                Quad quad7 = new Quad("3456JKL", "Monoplaza", 60.0, "Quad monoplaza con 450cc");
                quadDao.insert(quad7);

                // 2. INSERTAR RESERVAS DE PRUEBA
                // Fecha actual + 1 día
                Date fechaManana = new Date(System.currentTimeMillis() + 86400000);
                // Fecha actual + 2 días
                Date fechaPasadoManana = new Date(System.currentTimeMillis() + 172800000);

                Reserva reserva1 = new Reserva("Juan Pérez", "123456789",
                        new Date(), fechaManana, 150.0);
                long reserva1Id = reservaDao.insert(reserva1);

                Reserva reserva2 = new Reserva("María García", "987654321",
                        fechaManana, fechaPasadoManana, 75.0);
                long reserva2Id = reservaDao.insert(reserva2);

                Reserva reserva3 = new Reserva("Carlos López", "555444333",
                        new Date(System.currentTimeMillis() + 259200000), // +3 días
                        new Date(System.currentTimeMillis() + 345600000), // +4 días
                        120.0);
                long reserva3Id = reservaDao.insert(reserva3);

                // 3. RELACIONAR RESERVAS CON QUADS (ReservaQuad)
                // Reserva 1: 3 quads diferentes
                reservaQuadDao.insert(new ReservaQuad("1234ABC", (int)reserva1Id,
                        2)); // Quad adulto, 2 cascos
                reservaQuadDao.insert(new ReservaQuad("5678DEF", (int)reserva1Id,
                        1)); // Quad infantil, 1 casco
                reservaQuadDao.insert(new ReservaQuad("9012GHI", (int)reserva1Id,
                        2)); // Quad familiar, 2 cascos

                // Reserva 2: 1 quad
                reservaQuadDao.insert(new ReservaQuad("1234ABC", (int)reserva2Id,
                        1)); // Quad adulto, 1 casco

                // Reserva 3: 2 quads
                reservaQuadDao.insert(new ReservaQuad("3456JKL", (int)reserva3Id,
                        1)); // Quad deportivo, 1 casco
                reservaQuadDao.insert(new ReservaQuad("9012GHI", (int)reserva3Id,
                        2)); // Quad familiar, 2 cascos*/
            });
        }
    };

}
