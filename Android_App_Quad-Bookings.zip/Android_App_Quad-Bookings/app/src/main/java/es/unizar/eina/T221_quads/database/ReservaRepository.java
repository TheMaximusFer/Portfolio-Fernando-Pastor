package es.unizar.eina.T221_quads.database;


import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Clase que gestiona el acceso la fuente de datos.
 * Interacciona con la base de datos a través de las clases ReservaQuadsRoomDatabase y ReservaDao.
 */
public class ReservaRepository {

    private final ReservaDao mReservaDao;

    private final long TIMEOUT = 15000;

    /**
     * Constructor de ReservaRepository utilizando el contexto de la aplicación para instanciar la base de datos.
     * Alternativamente, se podría estudiar la instanciación del repositorio con una referencia a la base de datos
     * siguiendo el ejemplo de
     * <a href="https://github.com/android/architecture-components-samples/blob/main/BasicSample/app/src/main/java/com/example/android/persistence/DataRepository.java">architecture-components-samples/.../persistence/DataRepository</a>
     */
    public ReservaRepository(Application application) {
        ReservaQuadsRoomDatabase db = ReservaQuadsRoomDatabase.getDatabase(application);
        mReservaDao = db.reservaDao();
    }

    public LiveData<List<String>> getMatriculasForReserva(int reservaId) {
        return mReservaDao.getMatriculasForReserva(reservaId);
    }

    /** Devuelve un objeto de tipo LiveData con todas las Reservas ordenadas por el nombre del cliente de forma ascendente.
     * Room ejecuta todas las consultas en un hilo separado.
     * El objeto LiveData notifica a los observadores cuando los datos cambian.
     */
    public LiveData<List<Reserva>> getReservasByNombreClienteAsc() {
        return mReservaDao.getOrderedReservasByNombreClienteAsc();
    }

    /** Devuelve un objeto de tipo LiveData con todas las Reservas ordenadas por el nombre del cliente de forma descendente.
     * Room ejecuta todas las consultas en un hilo separado.
     * El objeto LiveData notifica a los observadores cuando los datos cambian.
     */
    public LiveData<List<Reserva>> getReservasByNombreClienteDesc() {
        return mReservaDao.getOrderedReservasByNombreClienteDesc();
    }

    /** Devuelve un objeto de tipo LiveData con todas las Reservas ordenadas por el teléfono del cliente de forma ascendente.
     * Room ejecuta todas las consultas en un hilo separado.
     * El objeto LiveData notifica a los observadores cuando los datos cambian.
     */
    public LiveData<List<Reserva>> getReservasByTelefonoClienteAsc() {
        return mReservaDao.getOrderedReservasByTelefonoClienteAsc();
    }

    /** Devuelve un objeto de tipo LiveData con todas las Reservas ordenadas por el teléfono del cliente de forma descendente.
     * Room ejecuta todas las consultas en un hilo separado.
     * El objeto LiveData notifica a los observadores cuando los datos cambian.
     */
    public LiveData<List<Reserva>> getReservasByTelefonoClienteDesc() {
        return mReservaDao.getOrderedReservasByTelefonoClienteDesc();
    }

    /** Devuelve un objeto de tipo LiveData con todas las Reservas ordenadas por la fecha de recogida de forma ascendente.
     * Room ejecuta todas las consultas en un hilo separado.
     * El objeto LiveData notifica a los observadores cuando los datos cambian.
     */
    public LiveData<List<Reserva>> getReservasByFechaRecogidaAsc() {
        return mReservaDao.getOrderedReservasByFechaRecogidaAsc();
    }

    /** Devuelve un objeto de tipo LiveData con todas las Reservas ordenadas por la fecha de recogida de forma descendente.
     * Room ejecuta todas las consultas en un hilo separado.
     * El objeto LiveData notifica a los observadores cuando los datos cambian.
     */
    public LiveData<List<Reserva>> getReservasByFechaRecogidaDesc() {
        return mReservaDao.getOrderedReservasByFechaRecogidaDesc();
    }

    /** Devuelve un objeto de tipo LiveData con todas las Reservas ordenadas por la fecha de devolución de forma ascendente.
     * Room ejecuta todas las consultas en un hilo separado.
     * El objeto LiveData notifica a los observadores cuando los datos cambian.
     */
    public LiveData<List<Reserva>> getReservasByFechaDevolucionAsc() {
        return mReservaDao.getOrderedReservasByFechaDevolucionAsc();
    }

    /** Devuelve un objeto de tipo LiveData con todas las Reservas ordenadas por la fecha de devolución de forma descendente.
     * Room ejecuta todas las consultas en un hilo separado.
     * El objeto LiveData notifica a los observadores cuando los datos cambian.
     */
    public LiveData<List<Reserva>> getReservasByFechaDevolucionDesc() {
        return mReservaDao.getOrderedReservasByFechaDevolucionDesc();
    }

    /** Inserta una Reserva nueva en la base de datos
     * @param reserva La Reserva consta de: un título (note.getTitle()) no nulo (note.getTitle()!=null) y no vacío
     *             (note.getTitle().length()>0); y un cuerpo (note.getBody()) no nulo.
     * @return Si la Reserva se ha insertado correctamente, devuelve el identificador de la Reserva que se ha creado. En caso
     *         contrario, devuelve -1 para indicar el fallo.
     */
    public long insert(Reserva reserva) {
        if (reserva == null){
            return -1;
        }

        // Validación de nombreCliente: length() > 0
        if (reserva.getNombreCliente() == null || reserva.getNombreCliente().trim().isEmpty()) {
            return -1;
        }
        
        // Validación de telefonoCliente: length() > 0 y solo dígitos [0-9]
        if (reserva.getTelefonoCliente() == null || reserva.getTelefonoCliente().trim().isEmpty()) {
            return -1;
        }
        String telefono = reserva.getTelefonoCliente().trim();
        if (telefono.length() != 9) {
            return -1;
        }
        for (int i = 0; i < telefono.length(); i++) {
            if (telefono.charAt(i) < '0' || telefono.charAt(i) > '9') {
                return -1;
            }
        }

        // Validación de fechaRecogida > fecha actual
        Date fechaActual = new Date();
        if (reserva.getFechaRecogida() == null || reserva.getFechaRecogida().compareTo(fechaActual) <= 0) {
            return -1;
        }
        
        // Validación de fechaDevolucion >= fechaRecogida
        if (reserva.getFechaDevolucion() == null || reserva.getFechaDevolucion().compareTo(reserva.getFechaRecogida()) < 0) {
            return -1;
        }
        
        // Validación de precioTotal: > 0
        if (reserva.getPrecioTotal() <= 0) {
            return -1;
        }
        
        /* Para que la App funcione correctamente y no lance una excepción, la modificación de la
         * base de datos se debe lanzar en un hilo de ejecución separado
         * (databaseWriteExecutor.submit). Para poder sincronizar la recuperación del resultado
         * devuelto por la base de datos, se puede utilizar un Future.
         */
        Future<Long> future = ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaDao.insert(reserva));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }

    /** Actualiza una Reserva en la base de datos
     * @param reserva La Reserva que se desea actualizar y que consta de: un identificador
     *             (Reserva.getMatricula()) mayor que 0; un título (note.getTitle()) no nulo y no vacío;
     *             y un cuerpo (note.getBody()) no nulo.
     * @return Un valor entero con el número de filas modificadas: 1 si el identificador se
     *         corresponde con una Reserva previamente insertada; 0 si no existe previamente una Reserva con
     *         ese identificador, o hay algún problema con los atributos.
     */
    public int update(Reserva reserva) {
        // Validación de id: >= 0
        if (reserva.getId() < 0) {
            return 0;
        }
        
        // Validación de nombreCliente: length() > 0
        if (reserva.getNombreCliente().isEmpty()) {
            return 0;
        }
        
        // Validación de telefonoCliente: length() > 0 y solo dígitos [0-9]
        if (reserva.getTelefonoCliente().isEmpty()) {
            return 0;
        }
        String telefono = reserva.getTelefonoCliente();
        for (int i = 0; i < telefono.length(); i++) {
            if (telefono.charAt(i) < '0' || telefono.charAt(i) > '9') {
                return 0;
            }
        }
        
        // Validación de fechaRecogida > fecha actual
        Date fechaActual = new Date();
        if (reserva.getFechaRecogida().compareTo(fechaActual) <= 0) {
            return 0;
        }
        
        // Validación de fechaDevolucion >= fechaRecogida
        if (reserva.getFechaDevolucion().compareTo(reserva.getFechaRecogida()) < 0) {
            return 0;
        }
        
        // Validación de precioTotal: >= 0
        if (reserva.getPrecioTotal() < 0) {
            return 0;
        }
        
        // Verificar que existe una reserva con ese id
        /*Future<Boolean> existsFuture = ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaDao.exists(reserva.getId()));
        try {
            boolean exists = existsFuture.get(TIMEOUT, TimeUnit.MILLISECONDS);
            if (!exists) {
                return 0;
            }
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }*/
        
        Future<Integer> future = ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaDao.update(reserva));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }


    /** Elimina una Reserva en la base de datos.
     * @param reserva Objeto Reserva cuyo atributo identificador (note.getId()) contiene la clave primaria de la Reserva que se
     *             va a eliminar de la base de datos. Se debe cumplir: note.getId() > 0.
     * @return Un valor entero con el número de filas eliminadas: 1 si el identificador se corresponde con una Reserva
     *         previamente insertada; 0 si no existe previamente una Reserva con ese identificador o el identificador no es
     *         un valor aceptable.
     */
    public int delete(Reserva reserva) {
        // Validación de id: >= 0
        if (reserva.getId() < 0) {
            return 0;
        }
        
        // Verificar que existe una reserva con ese id
        /*Future<Boolean> existsFuture = ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaDao.exists(reserva.getId()));
        try {
            boolean exists = existsFuture.get(TIMEOUT, TimeUnit.MILLISECONDS);
            if (!exists) {
                return -1;
            }
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }*/
        
        Future<Integer> future = ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaDao.delete(reserva));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }
}
