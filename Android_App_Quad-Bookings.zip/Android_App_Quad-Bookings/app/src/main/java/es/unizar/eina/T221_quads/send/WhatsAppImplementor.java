package es.unizar.eina.T221_quads.send;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

/** Concrete implementor utilizando la aplicación de WhatsApp. No funciona en el emulador si no se ha configurado previamente */
public class WhatsAppImplementor implements SendImplementor{
	
   /** actividad desde la cual se abrirá la aplicación de WhatsApp */
   private Activity sourceActivity;
   
   /** Constructor
    * @param source actividad desde la cual se abrira la aplicación de Whatsapp
    */
   public WhatsAppImplementor(Activity source){
	   setSourceActivity(source);
   }

   /**  Actualiza la actividad desde la cual se abrira la actividad de gestion de correo */
   public void setSourceActivity(Activity source) {
	   sourceActivity = source;
   }

   /**  Recupera la actividad desde la cual se abrira la aplicación de Whatsapp */
   public Activity getSourceActivity(){
     return sourceActivity;
   }

   /**
    * Implementacion del metodo send utilizando la aplicacion de WhatsApp
    * @param phone teléfono
    * @param message cuerpo del mensaje
    */
    public void send (String phone, String message) {
        if (phone == null || phone.trim().isEmpty()) {
            Toast.makeText(getSourceActivity(), "Número de teléfono inválido",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Formatear el teléfono: quitar TODOS los caracteres no numéricos (espacios, puntos, guiones, etc.)
        // Mantener solo números y el + al principio si existe
        String phoneFormatted = phone.replaceAll("[^0-9+]", "");
        
        // Si no tiene código de país (no empieza con +), añadir +34 (España)
        if (!phoneFormatted.startsWith("+")) {
            phoneFormatted = "+34" + phoneFormatted;
            Log.d("WhatsAppImplementor", "Añadido código de país +34");
        }
        
        // Para WhatsApp, necesitamos solo números sin el +
        String phoneForUrl = phoneFormatted;
        if (phoneForUrl.startsWith("+")) {
            phoneForUrl = phoneForUrl.substring(1); // Quitar el +
        }
        
        // Asegurarse de que solo queden números
        phoneForUrl = phoneForUrl.replaceAll("[^0-9]", "");
        
        Log.d("WhatsAppImplementor", "Teléfono original: " + phone);
        Log.d("WhatsAppImplementor", "Teléfono formateado: " + phoneFormatted);
        Log.d("WhatsAppImplementor", "Teléfono para URL: " + phoneForUrl);
        
        // Construir la URL de WhatsApp (solo números, sin +)
        String url = "https://wa.me/" + phoneForUrl + "?text=" + Uri.encode(message);
        Log.d("WhatsAppImplementor", "URL construida: " + url);
       
       // Intentar abrir WhatsApp directamente - método más simple y confiable
       try {
           Intent intent = new Intent(Intent.ACTION_VIEW);
           intent.setData(Uri.parse(url));
           
           // NO especificar package - dejar que el sistema elija la app adecuada
           // Esto permite que funcione incluso si hay problemas con el package name
           
           Log.d("WhatsAppImplementor", "Intentando abrir WhatsApp...");
           getSourceActivity().startActivity(intent);
           Log.d("WhatsAppImplementor", "Intent lanzado exitosamente");
           
       } catch (android.content.ActivityNotFoundException e) {
           // Si no hay app que pueda manejar este intent, WhatsApp no está instalado
           Log.e("WhatsAppImplementor", "ActivityNotFoundException: " + e.getMessage());
           Toast.makeText(getSourceActivity(), "WhatsApp no está instalado o no se puede abrir",
                   Toast.LENGTH_SHORT).show();
       } catch (Exception e) {
           // Cualquier otro error
           Log.e("WhatsAppImplementor", "Error inesperado: " + e.getMessage());
           e.printStackTrace();
           Toast.makeText(getSourceActivity(), "Error al abrir WhatsApp: " + e.getMessage(),
                   Toast.LENGTH_SHORT).show();
       }
   }
}