package es.unizar.eina.T221_quads.tests;

import android.app.Application;
import android.util.Log;

import java.util.concurrent.TimeUnit;

import es.unizar.eina.T221_quads.database.ReservaQuadsRoomDatabase;

public class Limpiar {
    private static final String TAG = "P6Volume";
    public static void limpiarRoomSimple(Application app) {
        try {
            ReservaQuadsRoomDatabase db = ReservaQuadsRoomDatabase.getDatabase(app);
            ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(db::clearAllTables).get(30, TimeUnit.SECONDS);
            Log.d(TAG, "Tablas limpiadas con clearAllTables()");

        } catch (Exception e) {
            Log.d(TAG, "Error: " + e.getMessage());
        }
    }
}
