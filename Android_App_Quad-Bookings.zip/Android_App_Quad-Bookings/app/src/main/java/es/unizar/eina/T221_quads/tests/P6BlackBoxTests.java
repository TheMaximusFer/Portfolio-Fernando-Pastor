package es.unizar.eina.T221_quads.tests;

import android.app.Application;
import android.util.Log;

import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import es.unizar.eina.T221_quads.database.Quad;
import es.unizar.eina.T221_quads.database.QuadRepository;
import es.unizar.eina.T221_quads.database.Reserva;
import es.unizar.eina.T221_quads.database.ReservaQuadsRoomDatabase;
import es.unizar.eina.T221_quads.database.ReservaRepository;


public final class P6BlackBoxTests {
    private static final String TAG = "P6BlackBox";
    
    // Rastrear datos creados durante las pruebas para limpiarlos al final
    private static final Set<String> quadsCreados = new HashSet<>();
    private static final Set<Integer> reservasCreadas = new HashSet<>();

    private P6BlackBoxTests() {}

    public static void runAll(Application app) {
        Log.d(TAG, "==============================");
        Log.d(TAG, "INICIO P6 CAJA NEGRA (repositorios)");
        Log.d(TAG, "==============================");
        
        // Limpiar listas de seguimiento
        quadsCreados.clear();
        reservasCreadas.clear();

        QuadRepository quadRepo = new QuadRepository(app);
        ReservaRepository reservaRepo = new ReservaRepository(app);

        runQuadTests(quadRepo);
        runReservaTests(reservaRepo);

        // Limpiar solo los datos de prueba creados durante la ejecución
        limpiarDatosPrueba(app);

        Log.d(TAG, "==============================");
        Log.d(TAG, "FIN P6 CAJA NEGRA");
        Log.d(TAG, "==============================");
    }
    
    private static void limpiarDatosPrueba(Application app) {
        if (quadsCreados.isEmpty() && reservasCreadas.isEmpty()) {
            Log.d(TAG, "---- No hay datos de prueba para limpiar ----");
            return;
        }
        
        Log.d(TAG, "---- Limpiando datos de prueba ----");
        try {
            ReservaQuadsRoomDatabase db = ReservaQuadsRoomDatabase.getDatabase(app);
            ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(() -> {
                // Primero eliminar las relaciones de las reservas de prueba
                for (Integer reservaId : reservasCreadas) {
                    try {
                        db.reservaQuadDao().deleteQuadsFromReserva(reservaId);
                    } catch (Exception e) {
                        // Ignorar si la reserva ya no existe
                    }
                }
                
                // Eliminar las reservas de prueba específicas
                for (Integer reservaId : reservasCreadas) {
                    try {
                        Reserva reserva = new Reserva("Temp", "000000000", new Date(), new Date(), 0.0);
                        reserva.setId(reservaId);
                        db.reservaDao().delete(reserva);
                    } catch (Exception e) {
                        // Ignorar si la reserva ya no existe (fue eliminada durante las pruebas)
                    }
                }
                
                // Eliminar los quads de prueba específicos
                for (String matricula : quadsCreados) {
                    try {
                        Quad quad = new Quad(matricula, "Monoplaza", 0.0, null);
                        db.quadDao().delete(quad);
                    } catch (Exception e) {
                        // Ignorar si el quad ya no existe (fue eliminado durante las pruebas)
                    }
                }
            }).get(5, TimeUnit.SECONDS);
            Log.d(TAG, "Datos de prueba eliminados correctamente (" + 
                  quadsCreados.size() + " quads, " + reservasCreadas.size() + " reservas)");
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            Log.d(TAG, "Error al limpiar datos de prueba: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // QUADS
    private static void runQuadTests(QuadRepository repo) {
        Log.d(TAG, "---- QuadRepository ----");

        // Matrículas válidas en formato NNNNLLL
        final String mOk = "0000BBB";
        final String mOk2 = "9999ZZZ";
        final String mNoExiste = "0001AAA";

        // INSERT - matrícula válida
        runCase("Q-INS-1 válido", () -> {
            Quad q1 = new Quad(mOk, "Monoplaza", 50.0, "desc");
            long r1 = repo.insert(q1);
            if (r1 > 0) {
                quadsCreados.add(mOk);
            }
            expect("Q-INS-1 válido", r1, v -> v > 0, ">0");
        });

        // INSERT - matrícula null
        runCase("Q-INS-2 matrícula null", () -> {
            Quad q2 = new Quad(null, "Monoplaza", 50.0, "desc");
            long r2 = repo.insert(q2);
            expect("Q-INS-2 matrícula null", r2, v -> v == -1, "-1");
        });

        // INSERT - matrícula vacía
        runCase("Q-INS-3 matrícula vacía", () -> {
            Quad q3 = new Quad("", "Monoplaza", 50.0, "desc");
            long r3 = repo.insert(q3);
            expect("Q-INS-3 matrícula vacía", r3, v -> v == -1, "-1");
        });

        // INSERT - Matrícula con formato incorrecto
        runCase("Q-INS-4 matrícula formato inválido", () -> {
            Quad q4 = new Quad("ABC123", "Monoplaza", 50.0, "desc");
            long r4 = repo.insert(q4);
            expect("Q-INS-6 matrícula formato inválido", r4, v -> v == -1, "-1");
        });

        // INSERT - Matrícula ya existente
        runCase("Q-INS-5 matrícula duplicada", () -> {
            Quad q5 = new Quad(mOk, "Monoplaza", 50.0, "desc");
            long r5 = repo.insert(q5);
            expect("Q-INS-5 matrícula duplicada", r5, v -> v == -1, "-1");
        });

        // INSERT - tipo null
        runCase("Q-INS-6 tipo null", () -> {
            Quad q6 = new Quad("0002BBB", null, 50.0, "desc");
            long r6 = repo.insert(q6);
            expect("Q-INS-4 tipo null", r6, v -> v == -1, "-1");
        });

        // INSERT - precio <= 0
        runCase("Q-INS-7 precio 0", () -> {
            Quad q7 = new Quad("0003BBB", "Monoplaza", 0.0, "desc");
            long r7 = repo.insert(q7);
            expect("Q-INS-5 precio 0", r7, v -> v == -1, "-1");
        });

        // UPDATE - válido (sobre mOk)
        runCase("Q-UPD-1 válido", () -> {
            Quad qUp = new Quad(mOk, "Monoplaza", 60.0, "desc nueva");
            int u1 = repo.update(qUp);
            expectInt("Q-UPD-1 válido", u1, v -> v == 1, "1");
        });

        // UPDATE - no existe
        runCase("Q-UPD-2 no existe", () -> {
            Quad qUp2 = new Quad(mNoExiste, "Monoplaza", 60.0, "desc");
            int u2 = repo.update(qUp2);
            expectInt("Q-UPD-2 no existe", u2, v -> v == 0, "0");
        });

        // DELETE - válido (sobre mOk)
        runCase("Q-DEL-1 válido", () -> {
            Quad qDel = new Quad(mOk, "Monoplaza", 1.0, null);
            int d1 = repo.delete(qDel);
            expectInt("Q-DEL-1 válido", d1, v -> v == 1, "1");
        });

        // DELETE - no existe
        runCase("Q-DEL-2 no existe", () -> {
            Quad qDel2 = new Quad(mNoExiste, "Monoplaza", 1.0, null);
            int d2 = repo.delete(qDel2);
            expectInt("Q-DEL-2 no existe", d2, v -> v == 0, "0");
        });
    }

    // -------------------------------------------------------------------------
    // RESERVAS
    private static void runReservaTests(ReservaRepository repo) {
        Log.d(TAG, "---- ReservaRepository ----");

        final long now = System.currentTimeMillis();
        // f1 debe ser > fecha actual (mañana)
        final Date f1 = new Date(now + 86400000L);
        final Date f2 = new Date(now + 172800000L); // +2 días

        // INSERT - válido
        final long[] idHolder = new long[] {-1};
        runCase("R-INS-1 válido", () -> {
            Reserva rOk = new Reserva("P6 Cliente", "600000000", f1, f2, 120.0);
            long id = repo.insert(rOk);
            idHolder[0] = id;
            if (id > 0) {
                reservasCreadas.add((int) id);
            }
            expect("R-INS-1 válido", id, v -> v > 0, ">0");
        });

        // INSERT - nombre null
        runCase("R-INS-2 nombre null", () -> {
            Reserva r2 = new Reserva(null, "600000000", f1, f2, 120.0);
            long id2 = repo.insert(r2);
            expect("R-INS-2 nombre null", id2, v -> v == -1, "-1");
        });

        // INSERT - nombre vacío
        runCase("R-INS-3 nombre vacío", () -> {
            Reserva r3 = new Reserva("", "600000000", f1, f2, 120.0);
            long id3 = repo.insert(r3);
            expect("R-INS-3 nombre vacío", id3, v -> v == -1, "-1");
        });

        // INSERT - teléfono null
        runCase("R-INS-4 teléfono null", () -> {
            Reserva r4 = new Reserva("P6 Cliente", null, f1, f2, 120.0);
            long id4 = repo.insert(r4);
            expect("R-INS-4 teléfono null", id4, v -> v == -1, "-1");
        });

        // INSERT - teléfono vacío
        runCase("R-INS-5 teléfono vacío", () -> {
            Reserva r5 = new Reserva("P6 Cliente", "", f1, f2, 120.0);
            long id5 = repo.insert(r5);
            expect("R-INS-5 teléfono vacío", id5, v -> v == -1, "-1");
        });

        // INSERT - Teléfono con formato incorrecto
        runCase("R-INS-6 teléfono formato inválido", () -> {
            Reserva r6 = new Reserva("Cliente", "123", f1, f2, 120.0);
            long id6 = repo.insert(r6);
            expect("R-INS-6 teléfono formato inválido", id6, v -> v == -1, "-1");
        });

        // INSERT - fechaRecogida null
        runCase("R-INS-7 fechaRecogida null", () -> {
            Reserva r7 = new Reserva("P6 Cliente", "600000000", null, f2, 120.0);
            long id7 = repo.insert(r7);
            expect("R-INS-7 fechaRecogida null", id7, v -> v == -1, "-1");
        });

        // INSERT - fechaDevolucion null
        runCase("R-INS-8 fechaDevolucion null", () -> {
            Reserva r8 = new Reserva("P6 Cliente", "600000000", f1, null, 120.0);
            long id8 = repo.insert(r8);
            expect("R-INS-8 fechaDevolucion null", id8, v -> v == -1, "-1");
        });

        // INSERT - Fecha recogida en el pasado
        runCase("R-INS-9 fecha recogida pasada", () -> {
            Date pasado = new Date(now - 86400000L); // Ayer
            Reserva r9 = new Reserva("Cliente", "600000000", pasado, f2, 120.0);
            long id9 = repo.insert(r9);
            expect("R-INS-9 fecha recogida pasada", id9, v -> v == -1, "-1");
        });

        // INSERT - fechaDevolucion <= fechaRecogida
        runCase("R-INS-10 fechas inválidas", () -> {
            Reserva r10 = new Reserva("P6 Cliente", "600000000", f1, new Date(now - 1000L), 120.0);
            long id10 = repo.insert(r10);
            expect("R-INS-10 fechas inválidas", id10, v -> v == -1, "-1");
        });

        // INSERT - precio <= 0
        runCase("R-INS-11 precio 0", () -> {
            Reserva r11 = new Reserva("P6 Cliente", "600000000", f1, f2, 0.0);
            long id11 = repo.insert(r11);
            expect("R-INS-11 precio 0", id11, v -> v == -1, "-1");
        });

        // UPDATE - válido (si inserción ok)
        runCase("R-UPD-1 válido", () -> {
            long id = idHolder[0];
            if (id <= 0) {
                Log.d(TAG, "R-UPD-1 omitido: no se pudo insertar reserva válida");
                return;
            }
            // Usar fechas futuras para el update también
            Date f1Upd = new Date(now + 86400000L);
            Date f2Upd = new Date(now + 172800000L);
            Reserva rUp = new Reserva("P6 Cliente", "600000000", f1Upd, f2Upd, 130.0);
            rUp.setId((int) id);
            int up = repo.update(rUp);
            expectInt("R-UPD-1 válido", up, v -> v == 1, "1");
        });

        // UPDATE - id no existe
        runCase("R-UPD-2 id no existe", () -> {
            Date f1Upd = new Date(now + 86400000L);
            Date f2Upd = new Date(now + 172800000L);
            Reserva rUp2 = new Reserva("P6 Cliente", "600000000", f1Upd, f2Upd, 130.0);
            rUp2.setId(99999999);
            int up2 = repo.update(rUp2);
            expectInt("R-UPD-2 id no existe", up2, v -> v == 0, "0");
        });

        // UPDATE - id <= 0
        runCase("R-UPD-3 id <= 0", () -> {
            Date f1Upd = new Date(now + 86400000L);
            Date f2Upd = new Date(now + 172800000L);
            Reserva rUp3 = new Reserva("P6 Cliente", "600000000", f1Upd, f2Upd, 130.0);
            rUp3.setId(0);
            int up3 = repo.update(rUp3);
            expectInt("R-UPD-3 id <= 0", up3, v -> v == 0, "0");
        });

        // DELETE - válido (si inserción ok)
        runCase("R-DEL-1 válido", () -> {
            long id = idHolder[0];
            if (id <= 0) {
                Log.d(TAG, "R-DEL-1 omitido: no se pudo insertar reserva válida");
                return;
            }
            Reserva rDel = new Reserva("P6 Cliente", "600000000", f1, f2, 120.0);
            rDel.setId((int) id);
            int del = repo.delete(rDel);
            expectInt("R-DEL-1 válido", del, v -> v == 1, "1");
        });

        // DELETE - no existe (id muy grande)
        runCase("R-DEL-2 id no existe", () -> {
            Reserva rNo = new Reserva("P6 NoExiste", "600000001", f1, f2, 120.0);
            rNo.setId(99999999);
            int delNo = repo.delete(rNo);
            expectInt("R-DEL-2 id no existe", delNo, v -> v == 0, "0");
        });
    }

    // -------------------------------------------------------------------------
    // Helpers
    private interface IntPredicate { boolean test(int v); }
    private interface LongPredicate { boolean test(long v); }

    private static void expectLong(String caseName, long actual, LongPredicate pred, String expected) {
        boolean ok = safe(pred, actual);
        Log.d(TAG, format(caseName, expected, String.valueOf(actual), ok));
    }

    private static void expectInt(String caseName, int actual, IntPredicate pred, String expected) {
        boolean ok = safe(pred, actual);
        Log.d(TAG, format(caseName, expected, String.valueOf(actual), ok));
    }
    
    // Métodos de compatibilidad para mantener el código existente
    private static void expect(String caseName, long actual, LongPredicate pred, String expected) {
        expectLong(caseName, actual, pred, expected);
    }

    private static void expect(String caseName, int actual, IntPredicate pred, String expected) {
        expectInt(caseName, actual, pred, expected);
    }

    private static boolean safe(LongPredicate p, long v) {
        try { return p.test(v); } catch (Throwable t) { return false; }
    }

    private static boolean safe(IntPredicate p, int v) {
        try { return p.test(v); } catch (Throwable t) { return false; }
    }

    private static String format(String caseName, String expected, String actual, boolean ok) {
        return String.format(Locale.getDefault(),
                "%s -> %s | esperado: %s | actual: %s",
                caseName,
                ok ? "PASS" : "FAIL",
                expected,
                actual
        );
    }

    private interface ThrowingRunnable { void run() throws Exception; }

    private static void runCase(String name, ThrowingRunnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            Log.d(TAG, name + " -> EXCEPCIÓN: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }
}