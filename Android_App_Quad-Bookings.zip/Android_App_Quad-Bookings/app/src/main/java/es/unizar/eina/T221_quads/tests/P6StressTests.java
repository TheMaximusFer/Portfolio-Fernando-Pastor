package es.unizar.eina.T221_quads.tests;

import android.app.Application;
import android.util.Log;

import java.util.HashSet;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import es.unizar.eina.T221_quads.database.Quad;
import es.unizar.eina.T221_quads.database.QuadRepository;
import es.unizar.eina.T221_quads.database.ReservaQuadsRoomDatabase;

public final class P6StressTests {
    private static final String TAG = "P6Stress";

    // Rastrear datos creados durante las pruebas para limpiarlos al final
    private static final Set<String> quadsCreados = new HashSet<>();
    private static final Random random = new Random();
    private static int contadorMatriculas = 0;

    private P6StressTests() {}

    public static void runAll(Application app) {
        Log.d(TAG, "==============================");
        Log.d(TAG, "INICIO P6 SOBRECARGA (Stress Tests)");
        Log.d(TAG, "==============================");

        // Limpiar listas de seguimiento
        quadsCreados.clear();
        contadorMatriculas = 0;

        QuadRepository quadRepo = new QuadRepository(app);

        // Ejecutar pruebas de sobrecarga según enunciado
        runDescripcionLargaTests(quadRepo);

        // Limpiar datos de prueba
        limpiarDatosStress(app);

        Log.d(TAG, "==============================");
        Log.d(TAG, "FIN P6 SOBRECARGA");
        Log.d(TAG, "==============================");
    }

    private static void limpiarDatosStress(Application app) {
        if (quadsCreados.isEmpty()) {
            Log.d(TAG, "---- No hay datos de sobrecarga para limpiar ----");
            return;
        }

        Log.d(TAG, "---- Limpiando datos de sobrecarga ----");
        try {
            ReservaQuadsRoomDatabase db = ReservaQuadsRoomDatabase.getDatabase(app);
            ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(() -> {
                // Eliminar los quads de sobrecarga
                for (String matricula : quadsCreados) {
                    try {
                        Quad quad = new Quad(matricula, "Monoplaza", 50.0, null);
                        db.quadDao().delete(quad);
                    } catch (Exception e) {
                        // Ignorar si ya no existe
                    }
                }
            }).get(10, TimeUnit.SECONDS);
            Log.d(TAG, "Datos de stress eliminados correctamente (" + quadsCreados.size() + " quads)");
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            Log.d(TAG, "Error al limpiar datos de sobrecarga: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // PRUEBAS DE DESCRIPCIÓN LARGA
    private static void runDescripcionLargaTests(QuadRepository repo) {
        Log.d(TAG, "---- Pruebas Descripción Larga ----");

        // CASO 1: Descripción normal (caso base)
        runCase("STRESS-DESC-1 Base (11 caracteres)", () -> {
            String descBase = "Desc normal";
            String matricula = generarMatriculaValida();
            Quad quad = new Quad(matricula, "Monoplaza", 50.0, descBase);
            long resultado = repo.insert(quad);
            if (resultado > 0) {
                quadsCreados.add(matricula);
                Log.d(TAG, "STRESS-DESC-1: Quad base insertado correctamente");
            } else {
                Log.d(TAG, "STRESS-DESC-1: Falló inserción de quad base");
            }
            expect("STRESS-DESC-1 Base", resultado, v -> v > 0, ">0");
        });

        // CASO 2: Descripción muy larga (encontrar límite)
        runCase("STRESS-DESC-2 Encontrar límite descripción", () -> {
            Log.d(TAG, "=== BUSCANDO LÍMITE DE DESCRIPCIÓN ===");

            int[] tamanos = {1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000, 1000000, 2000000, 5000000, 10000000};
            int limiteEncontrado = -1;

            for (int tamano : tamanos) {
                String matricula = generarMatriculaValida();
                String descripcion = generarDescripcionLarga(tamano);

                Log.d(TAG, "Probando: " + tamano + " caracteres...");
                //Log.d(TAG, "Matrícula: " + matricula);

                Quad quad = new Quad(matricula, "Monoplaza", 50.0, descripcion);
                long inicio = System.currentTimeMillis();
                long resultado = repo.insert(quad);
                long fin = System.currentTimeMillis();
                long tiempo = fin - inicio;

                if (resultado > 0) {
                    Log.d(TAG, "✓ ÉXITO: " + tamano + " caracteres insertados en " + tiempo + " ms");
                    limiteEncontrado = tamano;
                    quadsCreados.add(matricula);
                } else {
                    Log.d(TAG, "✗ FALLO: " + tamano + " caracteres (tiempo: " + tiempo + " ms)");
                    if (limiteEncontrado > 0) {
                        Log.d(TAG, "  Límite probablemente alrededor de: " + limiteEncontrado + " caracteres");
                    } else {
                        Log.d(TAG, "  Falló desde el primer intento");
                    }
                    break;
                }
            }
            probarTamanioIntermedio(repo, limiteEncontrado);
            expectInt("STRESS-DESC-2 Límite encontrado", limiteEncontrado, v -> v > 0, ">0");
        });

        // CASO 3: Descripción con caracteres especiales
        runCase("STRESS-DESC-3 Caracteres especiales", () -> {
            String matricula = generarMatriculaValida();
            String descEspecial = "Descripción con ñ y acentos áéíóú";
            Quad quad = new Quad(matricula, "Monoplaza", 50.0, descEspecial);
            long resultado = repo.insert(quad);
            if (resultado > 0) {
                quadsCreados.add(matricula);
            }

            expect("STRESS-DESC-3 Especiales", resultado, v -> v > 0, ">0");
        });

        // CASO 4: Descripción null (caso límite)
        runCase("STRESS-DESC-4 Descripción null", () -> {
            String matricula = generarMatriculaValida();
            Quad quad = new Quad(matricula, "Monoplaza", 50.0, null);
            long resultado = repo.insert(quad);

            if (resultado > 0) {
                quadsCreados.add(matricula);
            }
            expect("STRESS-DESC-4 null", resultado, v -> v > 0, ">0");
        });

        // CASO 5: Descripción vacía
        runCase("STRESS-DESC-5 Descripción vacía", () -> {
            String matricula = generarMatriculaValida();
            Quad quad = new Quad(matricula, "Monoplaza", 50.0, "");
            long resultado = repo.insert(quad);

            if (resultado > 0) {
                quadsCreados.add(matricula);
            }
            expect("STRESS-DESC-5 vacía", resultado, v -> v > 0, ">0");
        });
    }

    // -------------------------------------------------------------------------
    // Helpers
    private static String generarMatriculaValida() {
        contadorMatriculas++;
        // Usar timestamp para evitar duplicados entre ejecuciones
        long timestamp = System.currentTimeMillis();

        // Números: 1000-9999, variando con timestamp y contador
        int numero = 1000 + ((contadorMatriculas + (int)(timestamp % 10000)) % 9000);

        // Letras: variar con contador y random
        int letraBase = (contadorMatriculas * 17 + random.nextInt(26)) % (26*26*26);
        char letra1 = (char) ('A' + (letraBase % 26));
        char letra2 = (char) ('A' + ((letraBase / 26) % 26));
        char letra3 = (char) ('A' + ((letraBase / 676) % 26));

        return String.format(Locale.getDefault(), "%04d%c%c%c", numero, letra1, letra2, letra3);
    }

    private static String generarDescripcionLarga(int longitud) {
        StringBuilder sb = new StringBuilder();
        String base = "Esta es una descripción de prueba para verificar el límite de caracteres. ";

        // Repetir base hasta alcanzar longitud
        while (sb.length() < longitud) {
            sb.append(base);
        }

        // Recortar si nos pasamos
        String resultado = sb.substring(0, Math.min(sb.length(), longitud));

        // Añadir marcador final
        if (resultado.length() > 100) {
            resultado = resultado.substring(0, resultado.length() - 10) +
                    " [FIN-" + longitud + "]";
        }

        return resultado;
    }

    private static void probarTamanioIntermedio(QuadRepository repo, int ultimoExito) {
        Log.d(TAG, "\n=== PRUEBA HASTA FALLO ===");

        int limiteReal = ultimoExito;
        int incremento = 1000000; // 1M de incremento
        int maxPruebas = 20; // Máximo de intentos

        for (int i = 1; i <= maxPruebas; i++) {
            int tamanio = ultimoExito + (incremento * i);
            String matricula = generarMatriculaValida();

            Log.d(TAG, "Probando: " + String.format("%,d", tamanio) + " caracteres...");

            Quad quad = new Quad(matricula, "Monoplaza", 50.0, generarDescripcionLarga(tamanio));
            long resultado = repo.insert(quad);

            if (resultado > 0) {
                Log.d(TAG, "  ✓ " + String.format("%,d", tamanio) + " chars: ÉXITO");
                limiteReal = tamanio;
                quadsCreados.add(matricula);

                // Si llegamos a 100M, aumentar incremento
                if (tamanio > 100000000) {
                    incremento = 10000000; // 10M
                }
            } else {
                Log.d(TAG, String.format("%,d", tamanio) + " chars: FALLO");
                Log.d(TAG, "¡LÍMITE ENCONTRADO! Máximo: " + String.format("%,d", limiteReal) + " caracteres");
                break;
            }
        }

        if (limiteReal > ultimoExito) {
            Log.d(TAG, "LÍMITE MÁXIMO ENCONTRADO: " + String.format("%,d", limiteReal) + " caracteres");
        } else {
            Log.d(TAG, "No se encontró límite (probados hasta " +
                    String.format("%,d", ultimoExito + (incremento * maxPruebas)) + " chars)");
        }
    }

    private interface IntPredicate { boolean test(int v); }
    private interface LongPredicate { boolean test(long v); }

    private static void expectLong(String caseName, long actual, LongPredicate pred, String expected) {
        boolean ok = safe(pred, actual);
        Log.d(TAG, format(caseName, expected, String.valueOf(actual), ok));
    }

    private static void expectInt(String caseName, int actual, IntPredicate pred, String expected) {
        boolean ok = safe(pred, actual);
        Log.d(TAG, format(caseName, expected, String.valueOf(actual), ok));
    }

    private static void expect(String caseName, long actual, LongPredicate pred, String expected) {
        expectLong(caseName, actual, pred, expected);
    }

    private static boolean safe(LongPredicate p, long v) {
        try { return p.test(v); } catch (Throwable t) { return false; }
    }

    private static boolean safe(IntPredicate p, int v) {
        try { return p.test(v); } catch (Throwable t) { return false; }
    }

    private static String format(String caseName, String expected, String actual, boolean ok) {
        return String.format(Locale.getDefault(),
                "%s -> %s | esperado: %s | actual: %s",
                caseName,
                ok ? "PASS" : "FAIL",
                expected,
                actual
        );
    }

    private interface ThrowingRunnable { void run() throws Exception; }

    private static void runCase(String name, ThrowingRunnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            Log.d(TAG, name + " -> EXCEPCIÓN: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            Log.d(TAG, "Stack trace: " + Log.getStackTraceString(t));
        }
    }
}