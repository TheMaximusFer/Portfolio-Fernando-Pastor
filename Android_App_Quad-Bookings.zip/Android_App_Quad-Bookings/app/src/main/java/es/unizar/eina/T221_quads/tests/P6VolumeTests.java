package es.unizar.eina.T221_quads.tests;

import android.app.Application;
import android.util.Log;

import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import es.unizar.eina.T221_quads.database.Quad;
import es.unizar.eina.T221_quads.database.QuadRepository;
import es.unizar.eina.T221_quads.database.Reserva;
import es.unizar.eina.T221_quads.database.ReservaQuadsRoomDatabase;
import es.unizar.eina.T221_quads.database.ReservaRepository;

public final class P6VolumeTests {
    private static final String TAG = "P6Volume";

    // Rastrear datos creados durante las pruebas para limpiarlos al final
    private static final Set<String> quadsVolumen = new HashSet<>();
    private static final Set<Integer> reservasVolumen = new HashSet<>();

    private P6VolumeTests() {}

    public static void runAll(Application app) {
        Log.d(TAG, "==============================");
        Log.d(TAG, "INICIO P6 VOLUMEN");
        Log.d(TAG, "==============================");

        // Limpiar listas de seguimiento
        quadsVolumen.clear();
        reservasVolumen.clear();

        QuadRepository quadRepo = new QuadRepository(app);
        ReservaRepository reservaRepo = new ReservaRepository(app);

        // Ejecutar pruebas de volumen según requisitos: 0 quads, 100 quads, 101 quads, 0 reservas,
        // 20.000 reservas y 20.001 reservas
        runQuadVolumeTests(quadRepo);
        runReservaVolumeTests(reservaRepo);

        // Limpiar datos de prueba de volumen
        limpiarDatosVolumen(app);

        Log.d(TAG, "==============================");
        Log.d(TAG, "FIN P6 VOLUMEN");
        Log.d(TAG, "==============================");
    }

    private static void limpiarDatosVolumen(Application app) {
        Log.d(TAG, "---- Limpiando datos de volumen ----");
        try {
            ReservaQuadsRoomDatabase db = ReservaQuadsRoomDatabase.getDatabase(app);
            ReservaQuadsRoomDatabase.databaseWriteExecutor.submit(() -> {
                // Primero eliminar las relaciones de las reservas de volumen
                for (Integer reservaId : reservasVolumen) {
                    try {
                        db.reservaQuadDao().deleteQuadsFromReserva(reservaId);
                    } catch (Exception e) {
                        // Ignorar si ya no existe
                    }
                }

                // Eliminar las reservas de volumen
                for (Integer reservaId : reservasVolumen) {
                    try {
                        Reserva reserva = new Reserva("Temp", "000000000", new Date(), new Date(), 0.0);
                        reserva.setId(reservaId);
                        db.reservaDao().delete(reserva);
                    } catch (Exception e) {
                        // Ignorar si ya no existe
                    }
                }

                // Eliminar los quads de volumen
                for (String matricula : quadsVolumen) {
                    try {
                        Quad quad = new Quad(matricula, "Monoplaza", 0.0, null);
                        db.quadDao().delete(quad);
                    } catch (Exception e) {
                        // Ignorar si ya no existe
                    }
                }

            }).get(60, TimeUnit.SECONDS); // Más tiempo para limpiar los datos
            Log.d(TAG, "Datos de volumen eliminados correctamente (" +
                    quadsVolumen.size() + " quads, " + reservasVolumen.size() + " reservas)");
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            Log.d(TAG, "Error al limpiar datos de volumen: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // PRUEBAS DE VOLUMEN PARA QUADS
    private static void runQuadVolumeTests(QuadRepository repo) {
        Log.d(TAG, "---- Pruebas Volumen Quads ----");

        // CASO 1: Insertar 0 quads (caso base)
        runCase("VOL-Q-1 Insertar 0 quads", () -> {
            Log.d(TAG, "Caso base: base de datos con 0 quads");
            expectInt("VOL-Q-1 Base", 0, v -> v == 0, "0");
        });

        // CASO 2: Insertar 100 quads (valor límite)
        runCase("VOL-Q-2 Insertar 100 quads", () -> {
            Log.d(TAG, "Insertando 100 quads...");
            //int exitosos = 0;
            for (int i = 0; i < 100; i++) {
                String matricula = String.format("%04dAAA", i);
                Quad quad = new Quad(matricula,
                        i % 2 == 0 ? "Monoplaza" : "Biplaza",
                        50.0 + (i % 10),
                        "Quad volumen prueba #" + i);

                long resultado = repo.insert(quad);
                if (resultado > 0) {
                    //exitosos++;
                    quadsVolumen.add(matricula);
                }
            }
            expectInt("VOL-Q-2 100 quads", quadsVolumen.size(), v -> v == 100, "100");
        });

        // CASO 3: Insertar 1 quad más (101 en total)
        runCase("VOL-Q-3 101 quads insertados", () -> {
            Log.d(TAG, "Intentando insertar 1 quad adicional (101 total)...");

            // Insertar una matrícula nueva
            String matriculaExtra = "0000AAB";
            Quad quadExtra = new Quad(matriculaExtra, "Monoplaza", 60.0, "Quad extra");
            long resultado = repo.insert(quadExtra);
            if (resultado > 0) {
                quadsVolumen.add(matriculaExtra);
                expect("VOL-Q-3 101 quads", quadsVolumen.size(), v -> v == 101, "101");
            } else {
                expect("VOL-Q-3 101 quads", quadsVolumen.size(), v -> v == -1, "-1 (rechazado)");
            }
        });
    }

    // -------------------------------------------------------------------------
    // PRUEBAS DE VOLUMEN PARA RESERVAS
    private static void runReservaVolumeTests(ReservaRepository repo) {
        Log.d(TAG, "---- Pruebas Volumen Reservas ----");

        final long now = System.currentTimeMillis();

        // CASO 1: Insertar 0 reservas (caso base)
        runCase("VOL-R-1 Base (0 reservas)", () -> {
            Log.d(TAG, "Caso base: base de datos con 0 reservas");
            expectInt("VOL-R-1 Base", 0, v -> v == 0, "0");
        });

        // CASO 2: Insertar 20.000 reservas
        runCase("VOL-R-2 20.000 reservas", () -> {
            Log.d(TAG, "Insertando 20.000 reservas...");

            long ahora = System.currentTimeMillis();
            int loteSize = 1000; // Insertar en lotes de 1000

            // Dividir en lotes para mejor control
            for (int lote = 0; lote < 20; lote++) {
                for (int i = 0; i < loteSize; i++) {
                    int index = lote * loteSize + i;
                    String nombre = "Cliente" + lote + "-" + i;
                    String telefono = String.format("6%02d%06d", lote, i);

                    // Fechas escalonadas por lote para evitar solapamientos masivos
                    Date fechaRecogida = new Date(ahora + (86400000L * index) + 31536000000L);
                    Date fechaDevolucion = new Date(fechaRecogida.getTime() + 86400000L * (2 + (index % 5)));

                    Reserva reserva = new Reserva(nombre, telefono, fechaRecogida, fechaDevolucion, 80.0 + (index % 60));

                    long resultado = repo.insert(reserva);
                    if (resultado > 0) {
                        reservasVolumen.add((int) resultado);
                    }
                }

                // Pequeña pausa entre lotes
                if (lote < 19) { // No pausar después del último lote
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        // Continuar
                    }
                }
            }
            expectInt("VOL-R-2 20000 reservas", reservasVolumen.size(), v -> v == 20000, "20000");
        });

        // CASO 3: Insertar 1 reserva más (20001 en total)
        runCase("VOL-R-3 20001 reservas insertados", () -> {
            Log.d(TAG, "Intentando insertar 1 reserva adicional (20001 total)...");

            long ahora = System.currentTimeMillis();
            Date fechaRecogida = new Date(ahora + 86400000L + 31536000000L);
            Date fechaDevolucion = new Date(fechaRecogida.getTime() + 86400000L * 2);
            Reserva reservaExtra = new Reserva("nombre", "123456789", fechaRecogida, fechaDevolucion, 80.0);

            long resultado = repo.insert(reservaExtra);
            if (resultado > 0) {
                reservasVolumen.add((int) resultado);
                expect("VOL-R-3 20001 reservas", reservasVolumen.size(), v -> v == 20001, "20001");
            } else {
                expect("VOL-R-3 20001 reservas", reservasVolumen.size(), v -> v == -1, "-1 (rechazada)");
            }
        });
    }

    // -------------------------------------------------------------------------
    // Helpers
    private interface IntPredicate { boolean test(int v); }
    private interface LongPredicate { boolean test(long v); }

    private static void expectLong(String caseName, long actual, LongPredicate pred, String expected) {
        boolean ok = safe(pred, actual);
        Log.d(TAG, format(caseName, expected, String.valueOf(actual), ok));
    }

    private static void expectInt(String caseName, int actual, IntPredicate pred, String expected) {
        boolean ok = safe(pred, actual);
        Log.d(TAG, format(caseName, expected, String.valueOf(actual), ok));
    }

    private static void expect(String caseName, long actual, LongPredicate pred, String expected) {
        expectLong(caseName, actual, pred, expected);
    }

    private static boolean safe(LongPredicate p, long v) {
        try { return p.test(v); } catch (Throwable t) { return false; }
    }

    private static boolean safe(IntPredicate p, int v) {
        try { return p.test(v); } catch (Throwable t) { return false; }
    }

    private static String format(String caseName, String expected, String actual, boolean ok) {
        return String.format(Locale.getDefault(),
                "%s -> %s | esperado: %s | actual: %s",
                caseName,
                ok ? "PASS" : "FAIL",
                expected,
                actual
        );
    }

    private interface ThrowingRunnable { void run() throws Exception; }

    private static void runCase(String name, ThrowingRunnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            Log.d(TAG, name + " -> EXCEPCIÓN: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }
}