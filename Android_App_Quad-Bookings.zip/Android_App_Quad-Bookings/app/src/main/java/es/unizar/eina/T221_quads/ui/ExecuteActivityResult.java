package es.unizar.eina.T221_quads.ui;

import android.os.Bundle;

public interface ExecuteActivityResult {
    void process(Bundle extras, Object obj);
}