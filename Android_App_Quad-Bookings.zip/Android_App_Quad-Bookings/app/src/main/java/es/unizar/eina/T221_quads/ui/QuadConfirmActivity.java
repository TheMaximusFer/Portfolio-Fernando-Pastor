package es.unizar.eina.T221_quads.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import es.unizar.eina.T221_quads.R;

public class QuadConfirmActivity extends AppCompatActivity {

    public static final String EXTRA_MATRICULA = "matricula";
    public static final String EXTRA_TIPO = "tipo";
    public static final String EXTRA_PRECIO = "precio";
    public static final String EXTRA_DESCRIPCION = "descripcion";
    public static final String EXTRA_ES_CREACION = "es_creacion";
    public static final String EXTRA_CONFIRMED = "confirmed";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmarquad);

        // Obtener datos del intent
        String matricula = getIntent().getStringExtra(EXTRA_MATRICULA);
        String tipo = getIntent().getStringExtra(EXTRA_TIPO);
        String precioStr = getIntent().getStringExtra(EXTRA_PRECIO);
        String descripcion = getIntent().getStringExtra(EXTRA_DESCRIPCION);
        boolean esCreacion = getIntent().getBooleanExtra(EXTRA_ES_CREACION, true);

        if (matricula == null || tipo == null || precioStr == null) {
            finish();
            return;
        }

        // Configurar vistas
        TextView textMsg = findViewById(R.id.text_msg);
        Button buttonCancel = findViewById(R.id.button_cancel);
        Button buttonConfirm = findViewById(R.id.button_confirm);

        // Personalizar mensaje con los datos del quad
        String accion = esCreacion ? "crear" : "actualizar";
        String mensaje = String.format(
                "¿Confirmas que quieres %s este quad?\n\n" +
                        "- Matrícula: %s\n" +
                        "- Tipo: %s\n" +
                        "- Precio: %s€\n" +
                        "- Descripción: %s",
                accion,
                matricula,
                tipo,
                precioStr,
                descripcion != null && !descripcion.isEmpty() ? descripcion : "(sin descripción)"
        );
        textMsg.setText(mensaje);

        // Botón Cancelar
        buttonCancel.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });

        // Botón Confirmar
        buttonConfirm.setOnClickListener(v -> {
            Intent resultIntent = new Intent();
            resultIntent.putExtra(EXTRA_MATRICULA, matricula);
            resultIntent.putExtra(EXTRA_TIPO, tipo);
            resultIntent.putExtra(EXTRA_PRECIO, precioStr);
            resultIntent.putExtra(EXTRA_DESCRIPCION, descripcion);
            resultIntent.putExtra(EXTRA_CONFIRMED, true);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}

