package es.unizar.eina.T221_quads.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import es.unizar.eina.T221_quads.R;
import es.unizar.eina.T221_quads.database.Quad;

public class QuadDeleteActivity extends AppCompatActivity {

    public static final String EXTRA_QUAD = "quad";
    public static final String EXTRA_CONFIRMED = "confirmed";

    private Quad mQuad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminarquad);

        // Obtener el quad del intent
        mQuad = (Quad) getIntent().getSerializableExtra(EXTRA_QUAD);

        if (mQuad == null) {
            finish();
            return;
        }

        // Configurar vistas
        TextView textMsg = findViewById(R.id.text_msg);
        Button buttonCancel = findViewById(R.id.button_cancel);
        Button buttonDelete = findViewById(R.id.button_delete);

        // Personalizar mensaje con la matrícula del quad
        String mensaje = "¿Seguro que quieres eliminar el quad con matrícula " + mQuad.getMatricula() + "?";
        textMsg.setText(mensaje);

        // Botón Cancelar
        buttonCancel.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });

        // Botón Eliminar
        buttonDelete.setOnClickListener(v -> {
            Intent resultIntent = new Intent();
            resultIntent.putExtra(EXTRA_QUAD, mQuad);
            resultIntent.putExtra(EXTRA_CONFIRMED, true);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}