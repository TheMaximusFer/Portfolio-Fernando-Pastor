package es.unizar.eina.T221_quads.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.regex.Pattern;

import es.unizar.eina.T221_quads.R;

public class QuadEdit extends AppCompatActivity {

    public static final String QUAD_MATRICULA = "matricula";
    public static final String QUAD_TIPO = "tipo";
    public static final String QUAD_PRECIO = "precio";
    public static final String QUAD_DESCRIPCION = "descripcion";

    private EditText mMatriculaText;
    private EditText mPrecioText;
    private EditText mDescripcionText;
    private Spinner mTipoSpinner;
    private ActivityResultLauncher<Intent> mConfirmLauncher;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quadedit);

        // Determinar si es creación o edición
        Bundle extras = getIntent().getExtras();
        boolean esCreacion = extras == null || !extras.containsKey(QUAD_MATRICULA);

        // Cargar layout diferente
        if (esCreacion) {
            setContentView(R.layout.activity_quadregister);
        } else {
            setContentView(R.layout.activity_quadedit);
        }

        // Configurar launcher para confirmación
        mConfirmLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Bundle confirmExtras = result.getData().getExtras();
                        if (confirmExtras != null && confirmExtras.getBoolean(QuadConfirmActivity.EXTRA_CONFIRMED, false)) {
                            // Usuario confirmó, devolver los datos
                            Intent replyIntent = new Intent();
                            replyIntent.putExtra(QUAD_MATRICULA, confirmExtras.getString(QuadConfirmActivity.EXTRA_MATRICULA));
                            replyIntent.putExtra(QUAD_TIPO, confirmExtras.getString(QuadConfirmActivity.EXTRA_TIPO));
                            replyIntent.putExtra(QUAD_PRECIO, confirmExtras.getString(QuadConfirmActivity.EXTRA_PRECIO));
                            replyIntent.putExtra(QUAD_DESCRIPCION, confirmExtras.getString(QuadConfirmActivity.EXTRA_DESCRIPCION));
                            setResult(RESULT_OK, replyIntent);
                            finish();
                        }
                    }
                });

        // Enlazar vistas
        mMatriculaText = findViewById(R.id.matricula);
        mTipoSpinner = findViewById(R.id.spinner_tipo);
        mPrecioText = findViewById(R.id.precio);
        mDescripcionText = findViewById(R.id.descripcion);
        ImageButton mBackButton = findViewById(R.id.button_back);
        ImageButton mSaveButton = findViewById(R.id.button_save);

        configurarSpinner();

        // Configurar botones
        mSaveButton.setOnClickListener(view -> guardarQuad());
        mBackButton.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });

        populateFields();
    }

    private void configurarSpinner() {
        // Crear adapter usando el array de recursos con layouts personalizados
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.tipos_quad, R.layout.spinner_item);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        mTipoSpinner.setAdapter(adapter);
    }

    private void guardarQuad() {
        String matricula = mMatriculaText.getText().toString().toUpperCase().trim();

        // Patrón para validar la matrícula (4 números y 3 letras)
        Pattern matriculaPattern = Pattern.compile("^\\d{4}[A-Z]{3}$");

        if (TextUtils.isEmpty(matricula) || TextUtils.isEmpty(mPrecioText.getText())) {
            Toast.makeText(this, "Complete todos los campos obligatorios",
                    Toast.LENGTH_LONG).show();
        }else if (!matriculaPattern.matcher(matricula).matches()) {
            // Muestra un error si la matrícula no tiene el formato correcto
            mMatriculaText.setError("Formato de matrícula incorrecto (4 números y 3 letras)");
        } else {
            // Limpia el error si la validación es correcta
            mMatriculaText.setError(null);

            // Determinar si es creación o edición
            Bundle extras = getIntent().getExtras();
            boolean esCreacion = extras == null || !extras.containsKey(QUAD_MATRICULA);

            // Abrir pantalla de confirmación
            Intent confirmIntent = new Intent(this, QuadConfirmActivity.class);
            confirmIntent.putExtra(QuadConfirmActivity.EXTRA_MATRICULA, matricula);
            confirmIntent.putExtra(QuadConfirmActivity.EXTRA_TIPO, mTipoSpinner.getSelectedItem().toString());
            confirmIntent.putExtra(QuadConfirmActivity.EXTRA_PRECIO, mPrecioText.getText().toString());
            confirmIntent.putExtra(QuadConfirmActivity.EXTRA_DESCRIPCION, mDescripcionText.getText().toString());
            confirmIntent.putExtra(QuadConfirmActivity.EXTRA_ES_CREACION, esCreacion);
            mConfirmLauncher.launch(confirmIntent);
        }
    }

    private void populateFields() {
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey(QUAD_MATRICULA)) {
            // Cargar datos existentes para edición
            String matricula = extras.getString(QUAD_MATRICULA, "");
            mMatriculaText.setText(matricula);

            // Si hay matrícula, hacer el campo de solo lectura para edición
            if (!matricula.isEmpty()) {
                mMatriculaText.setEnabled(false);
            }

            // Seleccionar tipo en spinner
            String tipo = extras.getString(QUAD_TIPO, "");
            if (!tipo.isEmpty()) {
                for (int i = 0; i < mTipoSpinner.getCount(); i++) {
                    if (mTipoSpinner.getItemAtPosition(i).equals(tipo)) {
                        mTipoSpinner.setSelection(i);
                        break;
                    }
                }
            }

            // Cargar precio
            String precioStr = extras.getString(QUAD_PRECIO, "");
            if (precioStr != null && !precioStr.isEmpty()) {
                try {
                    double precio = Double.parseDouble(precioStr);
                    mPrecioText.setText(String.valueOf(precio));
                } catch (NumberFormatException e) {
                    mPrecioText.setText("");
                }
            }

            // Cargar descripción
            mDescripcionText.setText(extras.getString(QUAD_DESCRIPCION, ""));
        }
    }
}