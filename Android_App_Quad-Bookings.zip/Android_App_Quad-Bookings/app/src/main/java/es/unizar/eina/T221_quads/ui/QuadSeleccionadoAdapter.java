package es.unizar.eina.T221_quads.ui;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;

import es.unizar.eina.T221_quads.database.Quad;

public class QuadSeleccionadoAdapter extends ListAdapter<ReservaEdit.QuadSeleccionado,
        QuadSeleccionadoViewHolder> {

    public interface OnQuadSeleccionadoListener {
        void onCascosChanged(int position, int numCascos);
        void onEliminarQuad(int position);
    }

    private final OnQuadSeleccionadoListener  mListener;

    public QuadSeleccionadoAdapter(@NonNull DiffUtil.ItemCallback<ReservaEdit.QuadSeleccionado> diffCallback,
                                   @NonNull OnQuadSeleccionadoListener listener) {
        super(diffCallback);
        this.mListener = listener;
    }

    @NonNull
    @Override
    public QuadSeleccionadoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return QuadSeleccionadoViewHolder.create(parent);
    }

    @Override
    public void onBindViewHolder(@NonNull QuadSeleccionadoViewHolder holder, int position) {
        ReservaEdit.QuadSeleccionado current = getItem(position);

        // Enlazar datos del quad seleccionado
        holder.bind(current.getMatricula(), current.getTipo(), current.getPrecio(),
                current.getNumCascos(), position,
                mListener);
    }

    static class QuadSeleccionadoDiff extends DiffUtil.ItemCallback<ReservaEdit.QuadSeleccionado> {
        @Override
        public boolean areItemsTheSame(@NonNull ReservaEdit.QuadSeleccionado oldItem,
                                       @NonNull ReservaEdit.QuadSeleccionado newItem) {
            // Dos quads son el mismo si tienen la misma matrícula
            return oldItem.getMatricula().equals(newItem.getMatricula());
        }

        @Override
        public boolean areContentsTheSame(@NonNull ReservaEdit.QuadSeleccionado oldItem,
                                          @NonNull ReservaEdit.QuadSeleccionado newItem) {
            // Son iguales si no cambiaron matrícula, tipo, precio ni número de cascos
            return oldItem.getMatricula().equals(newItem.getMatricula()) &&
                    oldItem.getTipo().equals(newItem.getTipo()) &&
                    oldItem.getPrecio() == newItem.getPrecio() &&
                    oldItem.getNumCascos() == newItem.getNumCascos();
        }
    }
}