package es.unizar.eina.T221_quads.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

import es.unizar.eina.T221_quads.R;
import es.unizar.eina.T221_quads.database.Quad;

public class QuadSeleccionadoViewHolder extends RecyclerView.ViewHolder {
    private final TextView quadInfoTextView;
    private final RadioGroup radioGroupCascos;
    private final RadioButton radioCascos0;
    private final RadioButton radioCascos1;
    private final RadioButton radioCascos2;

    private QuadSeleccionadoAdapter.OnQuadSeleccionadoListener cascosListener;
    private int mAdapterPosition;

    private QuadSeleccionadoViewHolder(@NonNull View itemView) {
        super(itemView);
        quadInfoTextView = itemView.findViewById(R.id.quad_info);
        radioGroupCascos = itemView.findViewById(R.id.radio_group_cascos);
        radioCascos0 = itemView.findViewById(R.id.radio_cascos_0);
        radioCascos1 = itemView.findViewById(R.id.radio_cascos_1);
        radioCascos2 = itemView.findViewById(R.id.radio_cascos_2);
        ImageButton btnEliminar = itemView.findViewById(R.id.button_delete);

        // Configurar listeners
        radioGroupCascos.setOnCheckedChangeListener((group, checkedId) -> {
            if (cascosListener != null) {
                int numCascos = 0;
                if (checkedId == R.id.radio_cascos_1) {
                    numCascos = 1;
                } else if (checkedId == R.id.radio_cascos_2) {
                    numCascos = 2;
                }
                cascosListener.onCascosChanged(mAdapterPosition, numCascos);
            }
        });

        btnEliminar.setOnClickListener(v -> {
            if (cascosListener != null) {
                cascosListener.onEliminarQuad(mAdapterPosition);
            }
        });
    }

    public void bind(String matricula, String tipo, double precio, int numCascos,
                     int position, @NonNull QuadSeleccionadoAdapter.OnQuadSeleccionadoListener listener) {
        mAdapterPosition = position;
        cascosListener = listener;

        // Configurar la información del quad en el TextView
        String quadInfo = matricula + " - " + tipo + "\n (" + String.format(Locale.getDefault(), "%.2f", precio) + "€/día)";
        quadInfoTextView.setText(quadInfo);

        // Lógica para deshabilitar la opción de 2 cascos para monoplazas
        boolean esMonoplaza = "Monoplaza".equals(tipo);
        radioCascos2.setEnabled(!esMonoplaza);

        // Si es monoplaza y tenía 2 cascos seleccionados, se corrige a 1
        if (esMonoplaza && numCascos == 2) {
            numCascos = 1;
            // Se notifica el cambio para que el precio se recalcule si es necesario
            listener.onCascosChanged(position, 1);
        }

        // Configurar cascos
        radioGroupCascos.setOnCheckedChangeListener(null);
        switch (numCascos) {
            case 0:
                radioCascos0.setChecked(true);
                break;
            case 1:
                radioCascos1.setChecked(true);
                break;
            case 2:
                radioCascos2.setChecked(true);
                break;
        }

        // Restaurar el listener después de configurar
        radioGroupCascos.setOnCheckedChangeListener((group, checkedId) -> {
            if (cascosListener != null) {
                int newNumCascos = 0;
                if (checkedId == R.id.radio_cascos_1) {
                    newNumCascos = 1;
                } else if (checkedId == R.id.radio_cascos_2) {
                    newNumCascos = 2;
                }
                cascosListener.onCascosChanged(mAdapterPosition, newNumCascos);
            }
        });
    }

    static QuadSeleccionadoViewHolder create(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_quad_seleccionado, parent, false);
        return new QuadSeleccionadoViewHolder(view);
    }
}