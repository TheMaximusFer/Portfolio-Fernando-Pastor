package es.unizar.eina.T221_quads.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import es.unizar.eina.T221_quads.R;
import es.unizar.eina.T221_quads.database.Quad;

public class QuadViewHolder extends RecyclerView.ViewHolder {
    private final TextView matricula_tipo;
    private final TextView precio;
    private final TextView modelo;
    private final ImageView mImageView;
    public final ImageButton mEditButton;
    public final ImageButton mDeleteButton;

    public QuadViewHolder(View itemView) {
        super(itemView);
        matricula_tipo = itemView.findViewById(R.id.text_matricula_tipo);
        precio = itemView.findViewById(R.id.text_precio_dia);
        modelo = itemView.findViewById(R.id.text_modelo);
        mImageView = itemView.findViewById(R.id.image_quad);
        mEditButton = itemView.findViewById(R.id.button_edit);
        mDeleteButton = itemView.findViewById(R.id.button_delete);
    }

    public void bind(Quad quad) {
        matricula_tipo.setText(quad.getMatricula() + " - " + quad.getTipo());
        precio.setText(String.format("%.2f €/día", quad.getPrecio()));
        modelo.setText(quad.getDescripcion());
        mImageView.setImageResource(R.drawable.quad_imagen);
    }

    static QuadViewHolder create(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_quad, parent, false);
        return new QuadViewHolder(view);
    }
}