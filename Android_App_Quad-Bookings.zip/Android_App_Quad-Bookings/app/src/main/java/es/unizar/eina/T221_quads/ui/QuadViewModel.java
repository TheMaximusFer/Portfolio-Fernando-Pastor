package es.unizar.eina.T221_quads.ui;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

import es.unizar.eina.T221_quads.database.Quad;
import es.unizar.eina.T221_quads.database.QuadRepository;

public class QuadViewModel extends AndroidViewModel {

    private final QuadRepository mRepository;

    public QuadViewModel(Application application) {
        super(application);
        mRepository = new QuadRepository(application);
    }

    public LiveData<List<Quad>> getQuadsByMatriculas(List<String> matriculas) {
        return mRepository.getQuadsByMatriculas(matriculas);
    }

    public LiveData<List<Quad>> getQuadsByMatriculaAsc() { return mRepository.getQuadsByMatriculaAsc(); }

    public LiveData<List<Quad>> getQuadsByMatriculaDesc() { return mRepository.getQuadsByMatriculaDesc(); }

    public LiveData<List<Quad>> getQuadsByTipoAsc() { return mRepository.getQuadsByTipoAsc(); }

    public LiveData<List<Quad>> getQuadsByTipoDesc() { return mRepository.getQuadsByTipoDesc(); }

    public LiveData<List<Quad>> getQuadsByPrecioAsc() { return mRepository.getQuadsByPrecioAsc(); }

    public LiveData<List<Quad>> getQuadsByPrecioDesc() { return mRepository.getQuadsByPrecioDesc(); }

    public long insert(Quad quad) { return mRepository.insert(quad); }
    public void update(Quad quad) { mRepository.update(quad); }
    public void delete(Quad quad) { mRepository.delete(quad); }
}
