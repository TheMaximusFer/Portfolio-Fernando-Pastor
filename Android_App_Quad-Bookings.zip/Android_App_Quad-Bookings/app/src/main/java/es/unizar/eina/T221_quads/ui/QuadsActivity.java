package es.unizar.eina.T221_quads.ui;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import es.unizar.eina.T221_quads.R;
import es.unizar.eina.T221_quads.database.Quad;
import es.unizar.eina.T221_quads.tests.Limpiar;
import es.unizar.eina.T221_quads.tests.P6BlackBoxTests;
import es.unizar.eina.T221_quads.tests.P6VolumeTests;

import static androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult;

/** Pantalla principal para gestionar quads */
public class QuadsActivity extends AppCompatActivity implements QuadsAdapter.OnQuadClickListener {
    private QuadViewModel mQuadViewModel;

    RecyclerView mRecyclerView;
    QuadsAdapter mAdapter;
    FloatingActionButton mFab;
    MaterialAutoCompleteTextView mDropdownOrden;
    Button mButtonQuads;
    Button mButtonReservas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quads);

        // Configurar Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mRecyclerView = findViewById(R.id.recyclerview);
        mFab = findViewById(R.id.fab);
        mDropdownOrden = findViewById(R.id.dropdown_orden);
        mButtonQuads = findViewById(R.id.button_quads);
        mButtonReservas = findViewById(R.id.button_reservas);

        // Configurar RecyclerView
        mAdapter = new QuadsAdapter(new QuadsAdapter.QuadDiff(), this);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mQuadViewModel = new ViewModelProvider(this).get(QuadViewModel.class);

        // Cargar quads ordenados por defecto (matrícula)
        cargarQuadsOrdenados(0);

        // Configurar dropdown de ordenación
        configurarDropdownOrdenacion();

        // Botón flotante - Crear nuevo quad
        mFab.setOnClickListener(view -> mStartCreateQuad.launch(new Intent(this, QuadEdit.class)));

        // Navegación entre pantallas
        mButtonReservas.setOnClickListener(view -> {
            Intent intent = new Intent(QuadsActivity.this, ReservasActivity.class);
            startActivity(intent);
            finish();
        });

        mButtonQuads.setOnClickListener(view -> {
            mButtonReservas.setEnabled(true);
            mButtonQuads.setEnabled(false);
        });

        registerForContextMenu(mRecyclerView);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_p6_tests, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_run_p6_blackbox) {
            Toast.makeText(this, "Ejecutando P6 caja negra... mira Logcat (TAG=P6BlackBox)", Toast.LENGTH_LONG).show();
            P6BlackBoxTests.runAll(getApplication());
            return true;
        }
        if (item.getItemId() == R.id.action_run_p6_volumen) {
            Toast.makeText(this, "Ejecutando P6 volumen... mira Logcat (TAG=P6Volume)", Toast.LENGTH_LONG).show();
            P6VolumeTests.runAll(getApplication());
            return true;
        }
        if (item.getItemId() == R.id.limpiar_database) {
            Toast.makeText(this, "Limpiando base de datos", Toast.LENGTH_LONG).show();
            Limpiar.limpiarRoomSimple(getApplication());
            return true;
        }
        if (item.getItemId() == R.id.action_run_p6_stress) {
            Toast.makeText(this, "Ejecutando P6 sobrecarga... mira Logcat (TAG=P6Stress)", Toast.LENGTH_LONG).show();
            Limpiar.limpiarRoomSimple(getApplication());
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void configurarDropdownOrdenacion() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.orden_quads, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mDropdownOrden.setAdapter(adapter);

        mDropdownOrden.setOnItemClickListener((parent, view, position, id) ->
            cargarQuadsOrdenados(position)
        );
    }

    private void cargarQuadsOrdenados(int tipoOrden) {
        switch (tipoOrden) {
            case 0: // Matrícula (A-Z)
                mQuadViewModel.getQuadsByMatriculaAsc().observe(this, quads ->
                    mAdapter.submitList(quads)
                );
                break;
            case 1: // Matrícula (Z-A)
                mQuadViewModel.getQuadsByMatriculaDesc().observe(this, quads ->
                        mAdapter.submitList(quads)
                );
                break;
            case 2: // Tipo (A-Z)
                mQuadViewModel.getQuadsByTipoAsc().observe(this, quads ->
                    mAdapter.submitList(quads)
                );
                break;
            case 3: // Tipo (Z-A)
                mQuadViewModel.getQuadsByTipoDesc().observe(this, quads ->
                        mAdapter.submitList(quads)
                );
                break;
            case 4: // Precio ↑
                mQuadViewModel.getQuadsByPrecioAsc().observe(this, quads ->
                    mAdapter.submitList(quads)
                );
                break;
            case 5: // Precio ↓
                mQuadViewModel.getQuadsByPrecioDesc().observe(this, quads ->
                        mAdapter.submitList(quads)
                );
                break;
        }
    }

    // Launcher para crear quads
    ActivityResultLauncher<Intent> mStartCreateQuad = registerForActivityResult(
            new StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Bundle extras = result.getData().getExtras();
                    if (extras != null) {
                        String matricula = extras.getString(QuadEdit.QUAD_MATRICULA);
                        String tipo = extras.getString(QuadEdit.QUAD_TIPO);
                        String precioStr = extras.getString(QuadEdit.QUAD_PRECIO); // Se lee como String
                        String descripcion = extras.getString(QuadEdit.QUAD_DESCRIPCION);

                        double precio;
                        try {
                            precio = Double.parseDouble(precioStr);
                        } catch (NumberFormatException e) {
                            Toast.makeText(QuadsActivity.this, "Error en el formato del precio: " + precioStr, Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Quad quad = new Quad(matricula, tipo, precio, descripcion);

                        long resultId = mQuadViewModel.insert(quad);
                        if (resultId == -1) {
                            Toast.makeText(QuadsActivity.this, "La matrícula ya existe. Por favor, use una distinta.", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            });

    // Launcher para actualizar quads
    ActivityResultLauncher<Intent> mStartUpdateQuad = registerForActivityResult(
            new StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Bundle extras = result.getData().getExtras();
                    if (extras != null) {
                        String matricula = extras.getString(QuadEdit.QUAD_MATRICULA);
                        String tipo = extras.getString(QuadEdit.QUAD_TIPO);
                        String precioStr = extras.getString(QuadEdit.QUAD_PRECIO); // Se lee como String
                        String descripcion = extras.getString(QuadEdit.QUAD_DESCRIPCION);

                        double precio;
                        try {
                            precio = Double.parseDouble(precioStr);
                        } catch (NumberFormatException e) {
                            Toast.makeText(QuadsActivity.this, "Error en el formato del precio", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        Quad quad = new Quad(matricula, tipo, precio, descripcion);
                        mQuadViewModel.update(quad);
                    }
                }
            });

    // Launcher para eliminar quads
    ActivityResultLauncher<Intent> mStartDeleteQuad = registerForActivityResult(
            new StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Bundle extras = result.getData().getExtras();
                    if (extras != null && extras.getBoolean(QuadDeleteActivity.EXTRA_CONFIRMED, false)) {
                        Quad quad = (Quad) extras.getSerializable(QuadDeleteActivity.EXTRA_QUAD);
                        if (quad != null) {
                            mQuadViewModel.delete(quad);
                            Toast.makeText(QuadsActivity.this, "Quad eliminado: " + quad.getMatricula(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });

    @Override
    public void onEditClick(Quad quad) {
        if (quad != null) {
            Intent intent = new Intent(this, QuadEdit.class);
            intent.putExtra(QuadEdit.QUAD_MATRICULA, quad.getMatricula());
            intent.putExtra(QuadEdit.QUAD_TIPO, quad.getTipo());
            intent.putExtra(QuadEdit.QUAD_PRECIO, String.valueOf(quad.getPrecio()));
            intent.putExtra(QuadEdit.QUAD_DESCRIPCION, quad.getDescripcion());
            mStartUpdateQuad.launch(intent);
        }
    }

    @Override
    public void onDeleteClick(Quad quad) {
        Intent intent = new Intent(this, QuadDeleteActivity.class);
        intent.putExtra(QuadDeleteActivity.EXTRA_QUAD, quad);
        mStartDeleteQuad.launch(intent);
    }
}