package es.unizar.eina.T221_quads.ui;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;

import es.unizar.eina.T221_quads.database.Quad;

public class QuadsAdapter extends ListAdapter<Quad, QuadViewHolder> {
    private int position = -1;
    private final OnQuadClickListener mListener;

    public interface OnQuadClickListener {
        void onEditClick(Quad quad);
        void onDeleteClick(Quad quad);
    }

    public int getPosition() { return position; }

    public void setPosition(int position) { this.position = position; }

    public QuadsAdapter(@NonNull DiffUtil.ItemCallback<Quad> diffCallback,
                        OnQuadClickListener listener) {
        super(diffCallback);
        this.mListener = listener;
    }

    @NonNull
    @Override
    public QuadViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return QuadViewHolder.create(parent);
    }

    public Quad getCurrent() { return getItem(getPosition()); }

    public Quad getQuadSeleccionado() {
        if (position != -1 && position < getItemCount()) {
            return getItem(position);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(QuadViewHolder holder, int position) {
        Quad current = getItem(position);
        holder.bind(current);

        // Configurar botón editar
        holder.mEditButton.setOnClickListener(v -> {
            setPosition(holder.getAdapterPosition());
            if(mListener != null) mListener.onEditClick(getCurrent());
        });

        // Configurar botón eliminar
        holder.mDeleteButton.setOnClickListener(v -> {
            setPosition(holder.getAdapterPosition());
            if(mListener != null) mListener.onDeleteClick(getCurrent());
        });
    }

    static class QuadDiff extends DiffUtil.ItemCallback<Quad> {
        @Override
        public boolean areItemsTheSame(@NonNull Quad oldItem, @NonNull Quad newItem) {
            return oldItem.getMatricula().equals(newItem.getMatricula());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Quad oldItem, @NonNull Quad newItem) {
            return oldItem.getMatricula().equals(newItem.getMatricula()) &&
                    oldItem.getTipo().equals(newItem.getTipo()) &&
                    oldItem.getPrecio() == newItem.getPrecio();
        }
    }
}