package es.unizar.eina.T221_quads.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import es.unizar.eina.T221_quads.R;

public class ReservaConfirmActivity extends AppCompatActivity {

    public static final String EXTRA_NOMBRECLIENTE = "nombreCliente";
    public static final String EXTRA_TELEFONOCLIENTE = "telefonoCliente";
    public static final String EXTRA_FECHARECOGIDA = "fechaRecogida";
    public static final String EXTRA_FECHADEVOLUCION = "fechaDevolucion";
    public static final String EXTRA_PRECIOTOTAL = "precioTotal";
    public static final String EXTRA_RESERVA_ID = "id";
    public static final String EXTRA_MATRICULAS_QUADS = "matriculas_quads";
    public static final String EXTRA_NUM_CASCOS = "num_cascos";
    public static final String EXTRA_ES_CREACION = "es_creacion";
    public static final String EXTRA_CONFIRMED = "confirmed";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmarreserva);

        // Obtener datos del intent
        String nombreCliente = getIntent().getStringExtra(EXTRA_NOMBRECLIENTE);
        String telefonoCliente = getIntent().getStringExtra(EXTRA_TELEFONOCLIENTE);
        String fechaRecogida = getIntent().getStringExtra(EXTRA_FECHARECOGIDA);
        String fechaDevolucion = getIntent().getStringExtra(EXTRA_FECHADEVOLUCION);
        String precioTotal = getIntent().getStringExtra(EXTRA_PRECIOTOTAL);
        ArrayList<String> matriculas = getIntent().getStringArrayListExtra(EXTRA_MATRICULAS_QUADS);
        ArrayList<Integer> numCascos = getIntent().getIntegerArrayListExtra(EXTRA_NUM_CASCOS);
        boolean esCreacion = getIntent().getBooleanExtra(EXTRA_ES_CREACION, true);

        if (nombreCliente == null || telefonoCliente == null || fechaRecogida == null || 
            fechaDevolucion == null || precioTotal == null) {
            finish();
            return;
        }

        // Configurar vistas
        TextView textMsg = findViewById(R.id.text_msg);
        Button buttonCancel = findViewById(R.id.button_cancel);
        Button buttonConfirm = findViewById(R.id.button_confirm);

        // Construir resumen de quads
        String resumenQuads = "Ninguno";
        if (matriculas != null && !matriculas.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < matriculas.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(matriculas.get(i));
                if (numCascos != null && i < numCascos.size() && numCascos.get(i) > 0) {
                    sb.append(" (").append(numCascos.get(i)).append(" cascos)");
                }
            }
            resumenQuads = sb.toString();
        }

        // Personalizar mensaje con los datos de la reserva
        String accion = esCreacion ? "crear" : "actualizar";
        String mensaje = String.format(
                "¿Confirmas que quieres %s esta reserva?\n\n" +
                        "- Cliente: %s\n" +
                        "- Teléfono: %s\n" +
                        "- Fecha recogida: %s\n" +
                        "- Fecha devolución: %s\n" +
                        "- Quads: %s\n" +
                        "- Precio total: %s",
                accion,
                nombreCliente,
                telefonoCliente,
                fechaRecogida,
                fechaDevolucion,
                resumenQuads,
                precioTotal
        );
        textMsg.setText(mensaje);

        // Botón Cancelar
        buttonCancel.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });

        // Botón Confirmar
        buttonConfirm.setOnClickListener(v -> {
            Intent resultIntent = new Intent();
            resultIntent.putExtra(EXTRA_NOMBRECLIENTE, nombreCliente);
            resultIntent.putExtra(EXTRA_TELEFONOCLIENTE, telefonoCliente);
            resultIntent.putExtra(EXTRA_FECHARECOGIDA, fechaRecogida);
            resultIntent.putExtra(EXTRA_FECHADEVOLUCION, fechaDevolucion);
            resultIntent.putExtra(EXTRA_PRECIOTOTAL, precioTotal);
            if (getIntent().hasExtra(EXTRA_RESERVA_ID)) {
                resultIntent.putExtra(EXTRA_RESERVA_ID, getIntent().getIntExtra(EXTRA_RESERVA_ID, -1));
            }
            if (matriculas != null) {
                resultIntent.putStringArrayListExtra(EXTRA_MATRICULAS_QUADS, matriculas);
            }
            if (numCascos != null) {
                resultIntent.putIntegerArrayListExtra(EXTRA_NUM_CASCOS, numCascos);
            }
            resultIntent.putExtra(EXTRA_CONFIRMED, true);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}

