package es.unizar.eina.T221_quads.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import es.unizar.eina.T221_quads.R;
import es.unizar.eina.T221_quads.database.Reserva;

public class ReservaDeleteActivity extends AppCompatActivity {

    public static final String EXTRA_RESERVA = "reserva";
    public static final String EXTRA_CONFIRMED = "confirmed";

    private Reserva mReserva;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminarreserva);

        // Obtener la reserva del intent
        mReserva = (Reserva) getIntent().getSerializableExtra(EXTRA_RESERVA);

        if (mReserva == null) {
            finish();
            return;
        }

        // Configurar vistas
        TextView textMsg = findViewById(R.id.text_msg);
        Button buttonCancel = findViewById(R.id.button_cancel);
        Button buttonDelete = findViewById(R.id.button_delete);

        // Personalizar mensaje con los datos de la reserva
        String mensaje = String.format(
                "¿Seguro que quieres eliminar esta reserva?\n\n" +
                        "- Cliente: %s\n" +
                        "- Teléfono: %s\n" +
                        "- Fechas: %s\n" +
                        "- Quads: %s\n" +
                        "- Precio: %.2f€",
                mReserva.getNombreCliente(),
                mReserva.getTelefonoCliente(),
                mReserva.getFechasFormateadas(),
                mReserva.getResumenQuads(),
                mReserva.getPrecioTotal()
        );
        textMsg.setText(mensaje);

        // Botón Cancelar
        buttonCancel.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });

        // Botón Eliminar
        buttonDelete.setOnClickListener(v -> {
            Intent resultIntent = new Intent();
            resultIntent.putExtra(EXTRA_RESERVA, mReserva);
            resultIntent.putExtra(EXTRA_CONFIRMED, true);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}