package es.unizar.eina.T221_quads.ui;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import es.unizar.eina.T221_quads.R;
import es.unizar.eina.T221_quads.database.Quad;

public class ReservaEdit extends AppCompatActivity implements
        QuadSeleccionadoAdapter.OnQuadSeleccionadoListener {

    public static final String RESERVA_NOMBRECLIENTE = "nombreCliente";
    public static final String RESERVA_TELEFONOCLIENTE = "telefonoCliente";
    public static final String RESERVA_FECHARECOGIDA = "fechaRecogida";
    public static final String RESERVA_FECHADEVOLUCION = "fechaDevolucion";
    public static final String RESERVA_PRECIOTOTAL = "precioTotal";
    public static final String RESERVA_ID = "id";

    private EditText mNombreText;
    private EditText mTelefonoText;
    private EditText mFechaRecogidaText;
    private EditText mFechaDevolucionText;
    private TextView mPrecioTotalText;

    private Integer mRowId;
    private final List<ReservaEdit.QuadSeleccionado> mQuadsSeleccionados = new ArrayList<>();

    private QuadSeleccionadoAdapter mAdapter;
    private ReservaViewModel mReservaViewModel;
    private QuadViewModel mQuadViewModel;

    private ActivityResultLauncher<Intent> mSeleccionQuadsLauncher;
    private ActivityResultLauncher<Intent> mConfirmLauncher;

    private final Calendar mCalendarRecogida = Calendar.getInstance();
    private final Calendar mCalendarDevolucion = Calendar.getInstance();


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Determinar si es creación o edición
        Bundle extras = getIntent().getExtras();
        boolean esCreacion = extras == null || !extras.containsKey(RESERVA_ID);

        // Cargar layout diferente
        if (esCreacion) {
            setContentView(R.layout.activity_crearreserva);
        } else {
            setContentView(R.layout.activity_reserva_edit);
        }

        mReservaViewModel = new ViewModelProvider(this).get(ReservaViewModel.class);
        mQuadViewModel = new ViewModelProvider(this).get(QuadViewModel.class);

        mSeleccionQuadsLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            String matricula = data.getStringExtra(SeleccionQuadsActivity.QUAD_MATRICULA);
                            String tipo = data.getStringExtra(SeleccionQuadsActivity.QUAD_TIPO);
                            double precio = data.getDoubleExtra(SeleccionQuadsActivity.QUAD_PRECIO, 0.0);
                            mQuadsSeleccionados.add(new QuadSeleccionado(matricula, tipo, precio, 0));
                            List<ReservaEdit.QuadSeleccionado> nuevaLista = new ArrayList<>(mQuadsSeleccionados);
                            mAdapter.submitList(nuevaLista);
                            calcularPrecioTotal();
                            Log.d("ReservaEdit", "Quad agregado: " + matricula);
                            Log.d("ReservaEdit", "Total quads: " + mQuadsSeleccionados.size());
                        }
                    }
                }
        );

        // Configurar launcher para confirmación
        mConfirmLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Bundle confirmExtras = result.getData().getExtras();
                        if (confirmExtras != null && confirmExtras.getBoolean(ReservaConfirmActivity.EXTRA_CONFIRMED, false)) {
                            // Usuario confirmó, devolver los datos
                            Log.d("ReservaEdit", "Confirmación recibida, preparando datos para devolver");
                            Intent replyIntent = new Intent();
                            
                            String nombreCliente = confirmExtras.getString(ReservaConfirmActivity.EXTRA_NOMBRECLIENTE);
                            String telefonoCliente = confirmExtras.getString(ReservaConfirmActivity.EXTRA_TELEFONOCLIENTE);
                            String fechaRecogida = confirmExtras.getString(ReservaConfirmActivity.EXTRA_FECHARECOGIDA);
                            String fechaDevolucion = confirmExtras.getString(ReservaConfirmActivity.EXTRA_FECHADEVOLUCION);
                            String precioTotal = confirmExtras.getString(ReservaConfirmActivity.EXTRA_PRECIOTOTAL);
                            
                            Log.d("ReservaEdit", "Datos de confirmación - Nombre: " + nombreCliente + 
                                    ", Teléfono: " + telefonoCliente + 
                                    ", FechaRecogida: " + fechaRecogida + 
                                    ", FechaDevolucion: " + fechaDevolucion + 
                                    ", Precio: " + precioTotal);
                            
                            replyIntent.putExtra(RESERVA_NOMBRECLIENTE, nombreCliente);
                            replyIntent.putExtra(RESERVA_TELEFONOCLIENTE, telefonoCliente);
                            replyIntent.putExtra(RESERVA_FECHARECOGIDA, fechaRecogida);
                            replyIntent.putExtra(RESERVA_FECHADEVOLUCION, fechaDevolucion);
                            replyIntent.putExtra(RESERVA_PRECIOTOTAL, precioTotal);
                            
                            if (confirmExtras.containsKey(ReservaConfirmActivity.EXTRA_RESERVA_ID)) {
                                replyIntent.putExtra(RESERVA_ID, confirmExtras.getInt(ReservaConfirmActivity.EXTRA_RESERVA_ID));
                            }
                            
                            ArrayList<String> matriculas = confirmExtras.getStringArrayList(ReservaConfirmActivity.EXTRA_MATRICULAS_QUADS);
                            ArrayList<Integer> numCascos = confirmExtras.getIntegerArrayList(ReservaConfirmActivity.EXTRA_NUM_CASCOS);
                            
                            Log.d("ReservaEdit", "Matriculas: " + (matriculas != null ? matriculas.size() : "null") + 
                                    ", Cascos: " + (numCascos != null ? numCascos.size() : "null"));
                            
                            if (matriculas != null) {
                                replyIntent.putStringArrayListExtra("matriculas_quads", matriculas);
                            }
                            if (numCascos != null) {
                                replyIntent.putIntegerArrayListExtra("num_cascos", numCascos);
                            }
                            
                            setResult(RESULT_OK, replyIntent);
                            finish();
                        } else {
                            Log.d("ReservaEdit", "Confirmación cancelada o datos no válidos");
                        }
                    } else {
                        Log.d("ReservaEdit", "Resultado no OK o data null");
                    }
                });

        // Enlazar vistas
        mNombreText = findViewById(R.id.nombre_cliente);
        mTelefonoText = findViewById(R.id.telefono_cliente);
        mFechaRecogidaText = findViewById(R.id.fecha_recogida);
        mFechaDevolucionText = findViewById(R.id.fecha_devolucion);
        mPrecioTotalText = findViewById(R.id.precio_total);
        RecyclerView mQuadsRecyclerView = findViewById(R.id.quads_recyclerview);
        ImageButton mBackButton = findViewById(R.id.button_back);
        ImageButton mSaveButton = findViewById(R.id.button_save);
        Button mAddQuadButton = findViewById(R.id.button_add_quad);

        // Configurar RecyclerView
        mAdapter = new QuadSeleccionadoAdapter(new QuadSeleccionadoAdapter.QuadSeleccionadoDiff(),
                this);
        mQuadsRecyclerView.setAdapter(mAdapter);
        mQuadsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mAdapter.submitList(new ArrayList<>(mQuadsSeleccionados));

        //Configurar DatePickers para las fechas
        mFechaRecogidaText.setOnClickListener(v -> mostrarDatePicker(mFechaRecogidaText,
                mCalendarRecogida, true));
        mFechaDevolucionText.setOnClickListener(v -> mostrarDatePicker(mFechaDevolucionText,
                mCalendarDevolucion, false));

        // Hacer los campos no editables (solo mediante DatePicker)
        mFechaRecogidaText.setFocusable(false);
        mFechaRecogidaText.setClickable(true);
        mFechaDevolucionText.setFocusable(false);
        mFechaDevolucionText.setClickable(true);

        // Configurar botones
        mAddQuadButton.setOnClickListener(v -> abrirSeleccionQuads());
        mSaveButton.setOnClickListener(view -> guardarReserva());
        mBackButton.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });

        populateFields();
    }

    private void mostrarDatePicker(EditText field, Calendar calendar, boolean isRecogida) {
        DatePickerDialog datePicker = new DatePickerDialog(this, R.style.DatePickerDialogTheme,
                (view, year, month, dayOfMonth) -> {
                    calendar.set(Calendar.YEAR, year);
                    calendar.set(Calendar.MONTH, month);
                    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                    // Formatear fecha como "dd/MM/yyyy"
                    String fecha = String.format(Locale.getDefault(), "%02d/%02d/%d",
                            dayOfMonth, month + 1, year);
                    field.setText(fecha);

                    // Si es fecha de recogida, actualizar mínima para devolución
                    if (isRecogida) {
                        mCalendarDevolucion.setTimeInMillis(calendar.getTimeInMillis());
                        // La devolución no puede ser antes de la recogida
                        mCalendarDevolucion.add(Calendar.DAY_OF_MONTH, 1);
                    }

                    // Recalcular precio automáticamente
                    calcularPrecioTotal();
                    
                    // Verificar y eliminar quads no disponibles cuando cambian las fechas
                    verificarQuadsDisponibles();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        // Configurar fecha mínima
        if (isRecogida) {
            // Fecha recogida no puede ser anterior a hoy
            datePicker.getDatePicker().setMinDate(System.currentTimeMillis());
        } else {
            // Fecha devolución no puede ser anterior a fecha recogida
            if (mCalendarRecogida.getTimeInMillis() > 0) {
                datePicker.getDatePicker().setMinDate(mCalendarRecogida.getTimeInMillis());
            } else {
                datePicker.getDatePicker().setMinDate(System.currentTimeMillis());
            }
        }
        datePicker.show();
    }

    private void abrirSeleccionQuads() {
        // Validar que las fechas estén establecidas
        String fechaRecogidaStr = mFechaRecogidaText.getText().toString();
        String fechaDevolucionStr = mFechaDevolucionText.getText().toString();
        
        if (fechaRecogidaStr.isEmpty() || fechaDevolucionStr.isEmpty()) {
            Toast.makeText(this, "Debe establecer las fechas de recogida y devolución antes de añadir quads",
                    Toast.LENGTH_LONG).show();
            return;
        }
        
        // Validar que las fechas sean válidas
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date fechaRecogida = sdf.parse(fechaRecogidaStr);
            Date fechaDevolucion = sdf.parse(fechaDevolucionStr);
            
            if (fechaRecogida == null || fechaDevolucion == null) {
                Toast.makeText(this, "Las fechas no son válidas", Toast.LENGTH_SHORT).show();
                return;
            }
            
            if (!fechaDevolucion.after(fechaRecogida)) {
                Toast.makeText(this, "La fecha de devolución debe ser posterior a la de recogida",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            
            Intent intent = new Intent(this, SeleccionQuadsActivity.class);
            // Pasar quads ya seleccionados para evitar duplicados
            ArrayList<String> matriculasSeleccionadas = new ArrayList<>();
            for (QuadSeleccionado quad : mQuadsSeleccionados) {
                matriculasSeleccionadas.add(quad.getMatricula());
            }
            intent.putStringArrayListExtra("matriculas_seleccionadas", matriculasSeleccionadas);
            
            // Pasar fechas para filtrar quads disponibles
            intent.putExtra("fecha_recogida", fechaRecogida.getTime());
            intent.putExtra("fecha_devolucion", fechaDevolucion.getTime());
            intent.putExtra("excluir_reserva_id", mRowId != null ? mRowId : -1);
            
            mSeleccionQuadsLauncher.launch(intent);
        } catch (ParseException e) {
            Toast.makeText(this, "Error al procesar las fechas", Toast.LENGTH_SHORT).show();
            Log.e("ReservaEdit", "Error al parsear fechas", e);
        }
    }

    @Override
    public void onCascosChanged(int position, int numCascos) {
        mQuadsSeleccionados.get(position).setNumCascos(numCascos);
        calcularPrecioTotal();
    }

    @Override
    public void onEliminarQuad(int position) {
        mQuadsSeleccionados.remove(position);
        mAdapter.submitList(new ArrayList<>(mQuadsSeleccionados));
        calcularPrecioTotal();
    }

    private void calcularPrecioTotal() {
        if (mQuadsSeleccionados.isEmpty()) {
            mPrecioTotalText.setText(getString(R.string.precio_cero));
        } else {
            // Calcular días de alquiler (mínimo 1 día)
            int dias = 1;

            String fechaRecogidaStr = mFechaRecogidaText.getText().toString();
            String fechaDevolucionStr = mFechaDevolucionText.getText().toString();

            if (!fechaRecogidaStr.isEmpty() && !fechaDevolucionStr.isEmpty()) {
                try {
                    // Parsear fechas (depende de tu formato)
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy",
                            Locale.getDefault());
                    sdf.setLenient(false);
                    Date fechaRecogida = sdf.parse(fechaRecogidaStr);
                    Date fechaDevolucion = sdf.parse(fechaDevolucionStr);

                    if (fechaRecogida != null && fechaDevolucion != null) {
                        if (fechaDevolucion.after(fechaRecogida)) {
                            // Calcular diferencia en milisegundos
                            long diferencia = fechaDevolucion.getTime() - fechaRecogida.getTime();

                            // Convertir a días (redondear hacia arriba)
                            dias = (int) Math.max(1, Math.ceil(diferencia / (1000.0 * 60 * 60 * 24)));
                        } else {
                            // Fechas inválidas (devolución antes de recogida)
                            Toast.makeText(this, "La fecha de devolución debe ser " +
                                    "posterior a la de recogida", Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (ParseException e) {
                    // Formato de fecha incorrecto
                    // No mostrar error aquí para no spammear al usuario mientras escribe
                    Log.d("ReservaEdit", "Formato de fecha temporalmente incorrecto " +
                            "mientras el usuario escribe");
                } catch (Exception e) {
                    // Mantener valor por defecto si hay error en el parseo
                    Log.e("ReservaEdit", "Error calculando precio total", e);
                }
            }

            double precioTotal = 0;
            for (QuadSeleccionado quad : mQuadsSeleccionados) {
                precioTotal += quad.getPrecio() * dias;
            }
            mPrecioTotalText.setText(String.format(Locale.getDefault(), "%.2f€", precioTotal));
        }
    }

    private void guardarReserva() {
        if (TextUtils.isEmpty(mNombreText.getText()) || TextUtils.isEmpty(mTelefonoText.getText()) ||
                TextUtils.isEmpty(mFechaRecogidaText.getText()) ||
                TextUtils.isEmpty(mFechaDevolucionText.getText())) {
            boolean esCreacion = getIntent().getExtras() == null ||
                    !getIntent().getExtras().containsKey(RESERVA_ID);
            String mensaje = esCreacion ?
                    "Complete todos los campos para crear la reserva" :
                    "Complete todos los campos para actualizar la reserva";

            Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
            return;
        }

        if (mQuadsSeleccionados.isEmpty()) {
            Toast.makeText(this, "Seleccione al menos un quad",
                    Toast.LENGTH_LONG).show();
            return;
        }

        // Determinar si es creación o edición
        boolean esCreacion = getIntent().getExtras() == null ||
                !getIntent().getExtras().containsKey(RESERVA_ID);

        // Guardar información de los quads seleccionados
        ArrayList<String> matriculas = new ArrayList<>();
        ArrayList<Integer> numCascos = new ArrayList<>();
        for (QuadSeleccionado quad : mQuadsSeleccionados) {
            matriculas.add(quad.getMatricula());
            numCascos.add(quad.getNumCascos());
        }

        // Abrir pantalla de confirmación
        Intent confirmIntent = new Intent(this, ReservaConfirmActivity.class);
        confirmIntent.putExtra(ReservaConfirmActivity.EXTRA_NOMBRECLIENTE, mNombreText.getText().toString());
        confirmIntent.putExtra(ReservaConfirmActivity.EXTRA_TELEFONOCLIENTE, mTelefonoText.getText().toString());
        confirmIntent.putExtra(ReservaConfirmActivity.EXTRA_FECHARECOGIDA, mFechaRecogidaText.getText().toString());
        confirmIntent.putExtra(ReservaConfirmActivity.EXTRA_FECHADEVOLUCION, mFechaDevolucionText.getText().toString());
        confirmIntent.putExtra(ReservaConfirmActivity.EXTRA_PRECIOTOTAL, mPrecioTotalText.getText().toString());
        confirmIntent.putExtra(ReservaConfirmActivity.EXTRA_ES_CREACION, esCreacion);
        if (mRowId != null) {
            confirmIntent.putExtra(ReservaConfirmActivity.EXTRA_RESERVA_ID, mRowId.intValue());
        }
        confirmIntent.putStringArrayListExtra(ReservaConfirmActivity.EXTRA_MATRICULAS_QUADS, matriculas);
        confirmIntent.putIntegerArrayListExtra(ReservaConfirmActivity.EXTRA_NUM_CASCOS, numCascos);
        mConfirmLauncher.launch(confirmIntent);
    }

    private void populateFields() {
        mRowId = null;
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey(RESERVA_ID)) {
            // Estamos en modo EDICIÓN
            mRowId = extras.getInt(RESERVA_ID);

            mNombreText.setText(extras.getString(RESERVA_NOMBRECLIENTE));
            mTelefonoText.setText(extras.getString(RESERVA_TELEFONOCLIENTE));
            mPrecioTotalText.setText(extras.getString(RESERVA_PRECIOTOTAL));

            // Manejar fechas existentes
            String fechaRecogida = extras.getString(RESERVA_FECHARECOGIDA);
            String fechaDevolucion = extras.getString(RESERVA_FECHADEVOLUCION);

            if (fechaRecogida != null && !fechaRecogida.isEmpty()) {
                mFechaRecogidaText.setText(fechaRecogida);
                parsearFechaACalendar(fechaRecogida, mCalendarRecogida);
            }

            if (fechaDevolucion != null && !fechaDevolucion.isEmpty()) {
                mFechaDevolucionText.setText(fechaDevolucion);
                parsearFechaACalendar(fechaDevolucion, mCalendarDevolucion);
            }

            // Obtener los quads de la reserva de forma reactiva
            Log.d("ReservaEdit", "Cargando quads para reserva ID: " + mRowId);
            if (mRowId > 0) {
                LiveData<List<Quad>> quadsForReserva = mReservaViewModel.getQuadsDeReserva(mRowId);
                
                quadsForReserva.observe(this, quads -> {
                    Log.d("ReservaEdit", "Observer ejecutado. Quads recibidos: " + (quads != null ? quads.size() : "null"));
                    if (quads != null) {
                        if (!quads.isEmpty()) {
                            Log.d("ReservaEdit", "Cargando " + quads.size() + " quads en la lista");
                            cargarQuadsEnLista(quads);
                        } else {
                            Log.d("ReservaEdit", "Lista de quads vacía para reserva " + mRowId);
                            mQuadsSeleccionados.clear();
                            mAdapter.submitList(new ArrayList<>(mQuadsSeleccionados));
                        }
                    } else {
                        Log.d("ReservaEdit", "Quads es null para la reserva " + mRowId);
                        mQuadsSeleccionados.clear();
                        mAdapter.submitList(new ArrayList<>(mQuadsSeleccionados));
                    }
                });
            } else {
                Log.e("ReservaEdit", "ID de reserva inválido: " + mRowId);
            }
        }
    }

    private void parsearFechaACalendar(String fecha, Calendar calendar) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date date = sdf.parse(fecha);
            if (date != null) {
                calendar.setTime(date);
            }
        } catch (ParseException e) {
            Log.e("ReservaEdit", "Error al parsear la fecha: " + fecha, e);
        }
    }
    
    private void cargarQuadsEnLista(List<Quad> quads) {
        mQuadsSeleccionados.clear();
        if (!quads.isEmpty()) {
            for (Quad quad : quads) {
                // Obtener el número de cascos para este quad en esta reserva
                int numCascos = mReservaViewModel.getNumCascos(mRowId, quad.getMatricula());
                if (numCascos < 0) {
                    numCascos = 0; // Valor por defecto si hay error
                }
                Log.d("ReservaEdit", "Quad agregado: " + quad.getMatricula() + ", cascos: " + numCascos);
                mQuadsSeleccionados.add(new QuadSeleccionado(quad.getMatricula(), quad.getTipo(), quad.getPrecio(), numCascos));
            }
        }
        mAdapter.submitList(new ArrayList<>(mQuadsSeleccionados));
        calcularPrecioTotal();
        Log.d("ReservaEdit", "Total quads en lista: " + mQuadsSeleccionados.size());
    }
    
    private void verificarQuadsDisponibles() {
        String fechaRecogidaStr = mFechaRecogidaText.getText().toString();
        String fechaDevolucionStr = mFechaDevolucionText.getText().toString();
        
        // Solo verificar si hay fechas y quads seleccionados
        if (fechaRecogidaStr.isEmpty() || fechaDevolucionStr.isEmpty() || mQuadsSeleccionados.isEmpty()) {
            return;
        }
        
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date fechaRecogida = sdf.parse(fechaRecogidaStr);
            Date fechaDevolucion = sdf.parse(fechaDevolucionStr);
            
            if (fechaRecogida == null || fechaDevolucion == null || !fechaDevolucion.after(fechaRecogida)) {
                return;
            }
            
            // Obtener quads disponibles para el nuevo rango de fechas
            int excluirReservaId = mRowId != null ? mRowId : -1;
            LiveData<List<Quad>> quadsDisponibles = mReservaViewModel.getQuadsDisponibles(
                    fechaRecogida, fechaDevolucion, excluirReservaId);
            
            // Obtener valor actual si existe
            List<Quad> disponibles = quadsDisponibles.getValue();
            if (disponibles != null) {
                verificarYLimpiarQuadsNoDisponibles(disponibles);
            }
            
            // Observar cambios en los quads disponibles
            quadsDisponibles.observe(this, disponiblesList -> {
                if (disponiblesList != null) {
                    verificarYLimpiarQuadsNoDisponibles(disponiblesList);
                }
            });
        } catch (ParseException e) {
            Log.e("ReservaEdit", "Error al parsear fechas para verificar disponibilidad", e);
        }
    }
    
    private void verificarYLimpiarQuadsNoDisponibles(List<Quad> quadsDisponibles) {
        // Crear un conjunto de matrículas disponibles
        java.util.Set<String> matriculasDisponibles = new java.util.HashSet<>();
        for (Quad quad : quadsDisponibles) {
            matriculasDisponibles.add(quad.getMatricula());
        }
        
        // Eliminar quads que ya no están disponibles
        List<QuadSeleccionado> quadsAEliminar = new ArrayList<>();
        for (QuadSeleccionado quadSeleccionado : mQuadsSeleccionados) {
            if (!matriculasDisponibles.contains(quadSeleccionado.getMatricula())) {
                quadsAEliminar.add(quadSeleccionado);
            }
        }
        
        if (!quadsAEliminar.isEmpty()) {
            mQuadsSeleccionados.removeAll(quadsAEliminar);
            mAdapter.submitList(new ArrayList<>(mQuadsSeleccionados));
            calcularPrecioTotal();
            
            // Notificar al usuario
            if (quadsAEliminar.size() == 1) {
                Toast.makeText(this, 
                        "El quad " + quadsAEliminar.get(0).getMatricula() + 
                        " ya no está disponible en las nuevas fechas y ha sido eliminado",
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, 
                        quadsAEliminar.size() + " quads ya no están disponibles en las nuevas fechas y han sido eliminados",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    // Clase interna para representar un quad seleccionado
    public static class QuadSeleccionado implements android.os.Parcelable {
        private String matricula;
        private String tipo;
        private double precio;
        private int numCascos;

        public QuadSeleccionado(String matricula, String tipo, double precio, int numCascos) {
            this.matricula = matricula;
            this.tipo = tipo;
            this.precio = precio;
            this.numCascos = numCascos;
        }

        // Getters y Setters
        public String getMatricula() { return matricula; }
        public void setMatricula(String matricula) { this.matricula = matricula; }
        public String getTipo() { return tipo; }
        public void setTipo(String tipo) { this.tipo = tipo; }
        public double getPrecio() { return precio; }
        public void setPrecio(double precio) { this.precio = precio; }
        public int getNumCascos() { return numCascos; }
        public void setNumCascos(int numCascos) { this.numCascos = numCascos; }

        // Parcelable implementation
        protected QuadSeleccionado(android.os.Parcel in) {
            matricula = in.readString();
            tipo = in.readString();
            precio = in.readDouble();
            numCascos = in.readInt();
        }

        public static final Creator<QuadSeleccionado> CREATOR = new Creator<QuadSeleccionado>() {
            @Override
            public QuadSeleccionado createFromParcel(android.os.Parcel in) {
                return new QuadSeleccionado(in);
            }

            @Override
            public QuadSeleccionado[] newArray(int size) {
                return new QuadSeleccionado[size];
            }
        };

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(android.os.Parcel dest, int flags) {
            dest.writeString(matricula);
            dest.writeString(tipo);
            dest.writeDouble(precio);
            dest.writeInt(numCascos);
        }
    }
}