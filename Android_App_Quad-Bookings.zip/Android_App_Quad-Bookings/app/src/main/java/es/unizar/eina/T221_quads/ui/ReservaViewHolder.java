package es.unizar.eina.T221_quads.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import es.unizar.eina.T221_quads.R;
import es.unizar.eina.T221_quads.database.Quad;
import es.unizar.eina.T221_quads.database.Reserva;
import es.unizar.eina.T221_quads.send.SendAbstraction;
import es.unizar.eina.T221_quads.send.SendAbstractionImpl;

public class ReservaViewHolder extends RecyclerView.ViewHolder {
    private final TextView nombre_cliente;
    private final TextView telefono_cliente;
    private final TextView fechas;
    private final TextView quads_resumen;
    private final TextView precio_total;
    private final ImageButton button_edit;
    private final ImageButton button_send;
    private final ImageButton button_delete;
    private SendAbstraction sendAbstraction;
    
    // Referencias para eliminar observadores y evitar memory leaks
    private LiveData<List<Quad>> currentQuadsLiveData;
    private Observer<List<Quad>> currentQuadsObserver;
    private ViewModelStoreOwner currentOwner;

    private ReservaViewHolder(@NonNull View itemView) {
        super(itemView);
        nombre_cliente = itemView.findViewById(R.id.text_cliente);
        telefono_cliente = itemView.findViewById(R.id.text_telefono);
        fechas = itemView.findViewById(R.id.text_fechas);
        quads_resumen = itemView.findViewById(R.id.text_quads_resumen);
        precio_total = itemView.findViewById(R.id.text_total);

        button_edit = itemView.findViewById(R.id.button_edit);
        button_send = itemView.findViewById(R.id.button_send);
        button_delete = itemView.findViewById(R.id.button_delete);

        // sendAbstraction = new SendAbstractionImpl(itemView.getContext(), "WhatsApp");
    }

    public void bind(@NonNull Reserva reserva, ViewModelStoreOwner owner, LifecycleOwner lifecycleOwner) {
        nombre_cliente.setText(reserva.getNombreCliente());
        telefono_cliente.setText(reserva.getTelefonoCliente());
        fechas.setText(reserva.getFechasFormateadas());
        precio_total.setText("Total: " + String.format("%.2f €", reserva.getPrecioTotal()));
        
        // Eliminar observador anterior si existe para evitar memory leaks
        if (currentQuadsLiveData != null && currentQuadsObserver != null) {
            currentQuadsLiveData.removeObserver(currentQuadsObserver);
            currentQuadsLiveData = null;
            currentQuadsObserver = null;
        }
        
        // Si ya tiene resumen, usarlo; si no, cargar los quads
        if (reserva.getResumenQuads() != null && !reserva.getResumenQuads().isEmpty()) {
            quads_resumen.setText(reserva.getResumenQuads());
        } else {
            // Cargar quads para generar el resumen
            ReservaViewModel viewModel = new ViewModelProvider(owner).get(ReservaViewModel.class);
            currentQuadsLiveData = viewModel.getQuadsDeReserva(reserva.getId());
            currentOwner = owner;
            
            currentQuadsObserver = quads -> {
                if (quads != null) {
                    String resumen = generarResumenQuads(quads);
                    reserva.setResumenQuads(resumen);
                    quads_resumen.setText(resumen);
                } else {
                    quads_resumen.setText("Sin quads");
                }
            };
            
            currentQuadsLiveData.observe(lifecycleOwner, currentQuadsObserver);
        }
    }
    
    private String generarResumenQuads(List<Quad> quads) {
        if (quads == null || quads.isEmpty()) {
            return "Sin quads";
        }
        
        int totalQuads = quads.size();
        int monoplazas = 0;
        int biplazas = 0;
        
        for (Quad quad : quads) {
            if ("Monoplaza".equals(quad.getTipo())) {
                monoplazas++;
            } else if ("Biplaza".equals(quad.getTipo())) {
                biplazas++;
            }
        }
        
        StringBuilder resumen = new StringBuilder();
        resumen.append(totalQuads).append(" quad");
        if (totalQuads > 1) {
            resumen.append("s");
        }
        
        if (monoplazas > 0 || biplazas > 0) {
            resumen.append(" (");
            if (monoplazas > 0) {
                resumen.append(monoplazas).append(" mono");
                if (monoplazas > 1) {
                    resumen.append("s");
                }
            }
            if (monoplazas > 0 && biplazas > 0) {
                resumen.append(", ");
            }
            if (biplazas > 0) {
                resumen.append(biplazas).append(" bi");
                if (biplazas > 1) {
                    resumen.append("s");
                }
            }
            resumen.append(")");
        }
        
        return resumen.toString();
    }

    @NonNull
    public static ReservaViewHolder create(@NonNull ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_reserva, parent, false);
        return new ReservaViewHolder(view);
    }

    private void enviarReserva(Reserva reserva) {
        String mensaje = formatearMensajeReserva(reserva);
        String telefonoCliente = reserva.getTelefonoFormateado();

        if (telefonoCliente != null && !telefonoCliente.trim().isEmpty()) {
            sendAbstraction.send(telefonoCliente, mensaje);
        } else {
            Toast.makeText(itemView.getContext(),
                    "No hay número de teléfono disponible",
                    Toast.LENGTH_SHORT).show();
        }
    }

    // Añade este método
    private String formatearMensajeReserva(Reserva reserva) {
        return String.format(
                """
                        RESERVA CONFIRMADA
                        
                        Cliente: %s
                        Teléfono: %s
                        Fechas: %s
                        Resumen: %s
                        Total: %.2f€
                        
                        ¡Gracias por tu reserva!""",
                reserva.getNombreCliente(),
                reserva.getTelefonoCliente(),
                reserva.getFechasFormateadas(),
                reserva.getResumenQuads(),
                reserva.getPrecioTotal()
        );
    }

    public ImageButton getButtonEdit() { return button_edit; }
    public ImageButton getButtonSend() { return button_send; }
    public ImageButton getButtonDelete() { return button_delete; }
}