package es.unizar.eina.T221_quads.ui;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.Date;
import java.util.List;

import es.unizar.eina.T221_quads.database.Quad;
import es.unizar.eina.T221_quads.database.QuadRepository;
import es.unizar.eina.T221_quads.database.Reserva;
import es.unizar.eina.T221_quads.database.ReservaQuad;
import es.unizar.eina.T221_quads.database.ReservaQuadRepository;
import es.unizar.eina.T221_quads.database.ReservaRepository;

public class ReservaViewModel extends AndroidViewModel {

    private final ReservaRepository mReservaRepository;
    private final QuadRepository mQuadRepository;
    private final ReservaQuadRepository mReservaQuadRepository;

    public ReservaViewModel(Application application) {
        super(application);
        mReservaRepository = new ReservaRepository(application);
        mQuadRepository = new QuadRepository(application);
        mReservaQuadRepository = new ReservaQuadRepository(application);
    }

    public LiveData<List<String>> getMatriculasForReserva(int reservaId) {
        return mReservaRepository.getMatriculasForReserva(reservaId);
    }

    public LiveData<List<Reserva>> getReservasByNombreClienteAsc() {
        return mReservaRepository.getReservasByNombreClienteAsc();
    }

    public LiveData<List<Reserva>> getReservasByNombreClienteDesc() {
        return mReservaRepository.getReservasByNombreClienteDesc();
    }

    public LiveData<List<Reserva>> getReservasByTelefonoClienteAsc() {
        return mReservaRepository.getReservasByTelefonoClienteAsc();
    }

    public LiveData<List<Reserva>> getReservasByTelefonoClienteDesc() {
        return mReservaRepository.getReservasByTelefonoClienteDesc();
    }

    public LiveData<List<Reserva>> getReservasByFechaRecogidaAsc() {
        return mReservaRepository.getReservasByFechaRecogidaAsc();
    }

    public LiveData<List<Reserva>> getReservasByFechaRecogidaDesc() {
        return mReservaRepository.getReservasByFechaRecogidaDesc();
    }

    public LiveData<List<Reserva>> getReservasByFechaDevolucionAsc() {
        return mReservaRepository.getReservasByFechaDevolucionAsc();
    }

    public LiveData<List<Reserva>> getReservasByFechaDevolucionDesc() {
        return mReservaRepository.getReservasByFechaDevolucionDesc();
    }

    public long insert(Reserva reserva) { return mReservaRepository.insert(reserva); }
    public int update(Reserva reserva) { return mReservaRepository.update(reserva); }
    public int delete(Reserva reserva) { return mReservaRepository.delete(reserva); }

    public LiveData<List<Quad>> getQuadsDeReserva(int reservaId) {
        return mReservaQuadRepository.getQuadsByReserva(reservaId);
    }

    public int getNumCascos(int reservaId, String quadMatricula) {
        return mReservaQuadRepository.getNumCascos(reservaId, quadMatricula);
    }

    public long agregarQuadAReserva(int reservaId, String quadMatricula, int numCascos) {
        ReservaQuad relacion = new ReservaQuad(quadMatricula, reservaId, numCascos);
        return mReservaQuadRepository.insert(relacion);
    }

    //Obtener todos los quads
    public LiveData<List<Quad>> getTodosLosQuads() { return mQuadRepository.getQuadsByMatriculaAsc(); }

    /** Obtener quads disponibles en un rango de fechas */
    public LiveData<List<Quad>> getQuadsDisponibles(Date fechaInicio, Date fechaFin, int excluirReservaId) {
        return mQuadRepository.getQuadsDisponibles(fechaInicio, fechaFin, excluirReservaId);
    }

    public int eliminarQuadDeReserva(String quadMatricula, int reservaId) {
        return mReservaQuadRepository.deleteQuadFromReserva(quadMatricula, reservaId);
    }

    public int eliminarTodosQuadsDeReserva(int reservaId) {
        return mReservaQuadRepository.deleteQuadsFromReserva(reservaId);
    }

    /** Crear reserva completa con sus quads */
    public long crearReservaCompleta(Reserva reserva, List<String> matriculasQuads, List<Integer> numCascos) {
        Log.d("DEBUG_RESERVA", "=== crearReservaCompleta ===");
        Log.d("DEBUG_RESERVA", "Reserva: " + reserva.getNombreCliente() + ", precio: " + reserva.getPrecioTotal());
        Log.d("DEBUG_RESERVA", "Matriculas: " + matriculasQuads.size() + ", cascos: " + numCascos.size());
        // 1. Insertar la reserva principal
        long reservaId = mReservaRepository.insert(reserva);
        Log.d("DEBUG_RESERVA", "Reserva insertada, ID: " + reservaId);

        if (reservaId != -1) {
            // 2. Insertar todas las relaciones con quads
            for (int i = 0; i < matriculasQuads.size(); i++) {
                ReservaQuad relacion = new ReservaQuad(matriculasQuads.get(i), (int)reservaId, numCascos.get(i));
                long resultRelacion = mReservaQuadRepository.insert(relacion);
                Log.d("DEBUG_RESERVA", "Relacion " + matriculasQuads.get(i) + " insertada: " + resultRelacion);
            }
        } else {
            Log.e("DEBUG_RESERVA", "Error: No se pudo insertar la reserva principal");
        }
        return reservaId;
    }
}
