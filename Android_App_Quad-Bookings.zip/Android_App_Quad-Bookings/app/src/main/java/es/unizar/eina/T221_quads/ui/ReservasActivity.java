package es.unizar.eina.T221_quads.ui;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import es.unizar.eina.T221_quads.R;
import es.unizar.eina.T221_quads.database.Quad;
import es.unizar.eina.T221_quads.database.Reserva;
import es.unizar.eina.T221_quads.send.SendAbstraction;
import es.unizar.eina.T221_quads.send.SendAbstractionImpl;
import es.unizar.eina.T221_quads.tests.Limpiar;
import es.unizar.eina.T221_quads.tests.P6BlackBoxTests;
import es.unizar.eina.T221_quads.tests.P6StressTests;
import es.unizar.eina.T221_quads.tests.P6VolumeTests;

import static androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/** Pantalla principal para gestionar reservas */
public class ReservasActivity extends AppCompatActivity implements ReservasListAdapter.OnReservaActionListener {
    private ReservaViewModel mReservaViewModel;

    RecyclerView mRecyclerView;
    ReservasListAdapter mAdapter;
    FloatingActionButton mFab;
    MaterialAutoCompleteTextView mDropdownOrden;
    Button mButtonQuads;
    Button mButtonReservas;
    
    // Referencias para eliminar observadores y evitar memory leaks
    private LiveData<java.util.List<Reserva>> currentReservasLiveData;
    private Observer<java.util.List<Reserva>> currentReservasObserver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservas);

        // Configurar Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mRecyclerView = findViewById(R.id.recyclerview);
        mFab = findViewById(R.id.fab);
        mDropdownOrden = findViewById(R.id.dropdown_orden);
        mButtonQuads = findViewById(R.id.button_quads);
        mButtonReservas = findViewById(R.id.button_reservas);

        // Configurar RecyclerView
        mAdapter = new ReservasListAdapter(new ReservasListAdapter.ReservaDiff(), this, this, this);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mReservaViewModel = new ViewModelProvider(this).get(ReservaViewModel.class);

        // Cargar reservas ordenadas por defecto (nombre cliente)
        cargarReservasOrdenadas(0);

        // Configurar dropdown de ordenación
        configurarDropdownOrdenacion();

        // Botón flotante - Crear nueva reserva
        mFab.setOnClickListener(view -> createReserva());

        // Navegación entre pantallas
        mButtonQuads.setOnClickListener(view -> {
            Intent intent = new Intent(ReservasActivity.this, QuadsActivity.class);
            startActivity(intent);
            finish();
        });

        mButtonReservas.setOnClickListener(view -> {
            // Ya estamos en ReservasActivity
            mButtonReservas.setEnabled(false);
            mButtonQuads.setEnabled(true);
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_p6_tests, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_run_p6_blackbox) {
            Toast.makeText(this, "Ejecutando P6 caja negra... mira Logcat (TAG=P6BlackBox)", Toast.LENGTH_LONG).show();
            P6BlackBoxTests.runAll(getApplication());
            return true;
        }
        if (item.getItemId() == R.id.action_run_p6_volumen) {
            Toast.makeText(this, "Ejecutando P6 volumen... mira Logcat (TAG=P6BlackBox)", Toast.LENGTH_LONG).show();
            P6VolumeTests.runAll(getApplication());
            return true;
        }
        if (item.getItemId() == R.id.limpiar_database) {
            Toast.makeText(this, "Limpiando base de datos", Toast.LENGTH_LONG).show();
            Limpiar.limpiarRoomSimple(getApplication());
            return true;
        }
        if (item.getItemId() == R.id.action_run_p6_stress) {
            Toast.makeText(this, "Ejecutando P6 sobrecarga... mira Logcat (TAG=P6Stress)", Toast.LENGTH_LONG).show();
            P6StressTests.runAll(getApplication());
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void configurarDropdownOrdenacion() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.orden_reservas, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mDropdownOrden.setAdapter(adapter);

        mDropdownOrden.setOnItemClickListener((parent, view, position, id) ->
            cargarReservasOrdenadas(position)
        );
    }

    private void cargarReservasOrdenadas(int tipoOrden) {
        // Eliminar observador anterior si existe para evitar memory leaks
        if (currentReservasLiveData != null && currentReservasObserver != null) {
            currentReservasLiveData.removeObserver(currentReservasObserver);
            currentReservasLiveData = null;
            currentReservasObserver = null;
        }
        
        // Crear nuevo observador
        currentReservasObserver = reservas -> mAdapter.submitList(reservas);
        
        switch (tipoOrden) {
            case 0: // Nombre Cliente (A-Z)
                currentReservasLiveData = mReservaViewModel.getReservasByNombreClienteAsc();
                currentReservasLiveData.observe(this, currentReservasObserver);
                break;
            case 1: // Nombre Cliente (Z-A)
                currentReservasLiveData = mReservaViewModel.getReservasByNombreClienteDesc();
                currentReservasLiveData.observe(this, currentReservasObserver);
                break;
            case 2: // Teléfono Cliente ↑
                currentReservasLiveData = mReservaViewModel.getReservasByTelefonoClienteAsc();
                currentReservasLiveData.observe(this, currentReservasObserver);
                break;
            case 3: // Teléfono Cliente ↓
                currentReservasLiveData = mReservaViewModel.getReservasByTelefonoClienteDesc();
                currentReservasLiveData.observe(this, currentReservasObserver);
                break;
            case 4: // Fecha Recogida ↑
                currentReservasLiveData = mReservaViewModel.getReservasByFechaRecogidaAsc();
                currentReservasLiveData.observe(this, currentReservasObserver);
                break;
            case 5: // Fecha Recogida ↓
                currentReservasLiveData = mReservaViewModel.getReservasByFechaRecogidaDesc();
                currentReservasLiveData.observe(this, currentReservasObserver);
                break;
            case 6: // Fecha Devolución ↑
                currentReservasLiveData = mReservaViewModel.getReservasByFechaDevolucionAsc();
                currentReservasLiveData.observe(this, currentReservasObserver);
                break;
            case 7: // Fecha Devolución ↓
                currentReservasLiveData = mReservaViewModel.getReservasByFechaDevolucionDesc();
                currentReservasLiveData.observe(this, currentReservasObserver);
                break;
        }
    }

    private void createReserva() {
        mStartCreateReserva.launch(new Intent(this, ReservaEdit.class));
    }

    ActivityResultLauncher<Intent> mStartCreateReserva = newActivityResultLauncher(new ExecuteActivityResult() {
        @Override
        public void process(Bundle extras, Object obj) {
            Reserva reserva = (Reserva) obj;

            ArrayList<String> matriculas = extras.getStringArrayList("matriculas_quads");
            ArrayList<Integer> numCascos = extras.getIntegerArrayList("num_cascos");

            // Logs para depuración
            Log.d("ReservasActivity", "=== Crear Reserva ===");
            Log.d("ReservasActivity", "Reserva - Cliente: " + reserva.getNombreCliente() + 
                    ", Teléfono: " + reserva.getTelefonoCliente() + 
                    ", Precio: " + reserva.getPrecioTotal());
            Log.d("ReservasActivity", "Fechas - Recogida: " + reserva.getFechaRecogida() + 
                    ", Devolución: " + reserva.getFechaDevolucion());
            Log.d("ReservasActivity", "Matriculas: " + (matriculas != null ? matriculas.size() : "null") + 
                    ", Cascos: " + (numCascos != null ? numCascos.size() : "null"));

            if (matriculas != null && numCascos != null && !matriculas.isEmpty()) {
                // Usar crearReservaCompleta para guardar reserva y quads
                long reservaId = mReservaViewModel.crearReservaCompleta(reserva, matriculas, numCascos);
                if (reservaId == -1) {
                    Log.e("ReservasActivity", "Error: crearReservaCompleta devolvió -1");
                    Toast.makeText(ReservasActivity.this, "Error al crear la reserva. Verifica los datos (fechas futuras, teléfono de 9 dígitos, precio > 0)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(ReservasActivity.this, "Reserva creada exitosamente", Toast.LENGTH_SHORT).show();
                }
            } else {
                Log.e("ReservasActivity", "Error: No hay quads seleccionados");
                // Si no hay quads, solo insertar la reserva (aunque no debería pasar por validación)
                long result = mReservaViewModel.insert(reserva);
                if (result == -1) {
                    Toast.makeText(ReservasActivity.this, "Error al crear la reserva. Verifica los datos", Toast.LENGTH_LONG).show();
                }
            }
        }
    });

    ActivityResultLauncher<Intent> newActivityResultLauncher(ExecuteActivityResult executable) {
        return registerForActivityResult(
                new StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Bundle extras = result.getData().getExtras();
                        if (extras != null) {
                            try {
                                // Convertir Strings a Date
                                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                                String fechaRecogidaStr = extras.getString(ReservaEdit.RESERVA_FECHARECOGIDA);
                                String fechaDevolucionStr = extras.getString(ReservaEdit.RESERVA_FECHADEVOLUCION);
                                String precioStr = extras.getString(ReservaEdit.RESERVA_PRECIOTOTAL);

                                if (fechaRecogidaStr != null && fechaDevolucionStr != null && precioStr != null) {
                                    Date fechaRecogida = sdf.parse(fechaRecogidaStr);
                                    Date fechaDevolucion = sdf.parse(fechaDevolucionStr);
                                    //double precio = Double.parseDouble(precioStr.replace("€", "").trim());
                                    double precio = 0.0;
                                    try {
                                        // Eliminar TODOS los caracteres no numéricos (incluyendo €, $, etc.)
                                        String precioLimpio = precioStr.replaceAll("[^\\d.,-]", "").replace(',', '.');
                                        precio = Double.parseDouble(precioLimpio);
                                        Log.d("ReservasActivity", "Precio parseado: " + precio + " (de: " + precioStr + ")");
                                    } catch (NumberFormatException e) {
                                        Log.e("ReservasActivity", "Error parseando precio: " + precioStr, e);
                                        Toast.makeText(ReservasActivity.this,
                                                "Error en formato de precio: " + precioStr,
                                                Toast.LENGTH_SHORT).show();
                                        return;
                                    }

                                    String nombreCliente = extras.getString(ReservaEdit.RESERVA_NOMBRECLIENTE);
                                    String telefonoCliente = extras.getString(ReservaEdit.RESERVA_TELEFONOCLIENTE);
                                    
                                    Log.d("ReservasActivity", "Datos recibidos - Nombre: " + nombreCliente + 
                                            ", Teléfono: " + telefonoCliente + 
                                            ", FechaRecogida: " + fechaRecogida + 
                                            ", FechaDevolucion: " + fechaDevolucion + 
                                            ", Precio: " + precio);

                                    Reserva reserva = new Reserva(
                                            nombreCliente,
                                            telefonoCliente,
                                            fechaRecogida,
                                            fechaDevolucion,
                                            precio
                                    );

                                    if (extras.containsKey(ReservaEdit.RESERVA_ID)) {
                                        reserva.setId(extras.getInt(ReservaEdit.RESERVA_ID));
                                    }
                                    ArrayList<String> matriculas = extras.getStringArrayList("matriculas_quads");
                                    ArrayList<Integer> numCascos = extras.getIntegerArrayList("num_cascos");
                                    executable.process(extras, reserva);
                                } else {
                                    Log.e("ReservasActivity", "Datos incompletos - fechaRecogida: " + fechaRecogidaStr + 
                                            ", fechaDevolucion: " + fechaDevolucionStr + 
                                            ", precio: " + precioStr);
                                    Toast.makeText(ReservasActivity.this, "Datos incompletos", Toast.LENGTH_SHORT).show();
                                }
                            } catch (Exception e) {
                                Toast.makeText(ReservasActivity.this, "Error en formato de datos", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
    }

    ActivityResultLauncher<Intent> mStartUpdateReserva = newActivityResultLauncher(new ExecuteActivityResult() {
        @Override
        public void process(Bundle extras, Object obj) {
            Reserva reserva = (Reserva) obj;
            int id = extras.getInt(ReservaEdit.RESERVA_ID);
            reserva.setId(id);
            
            // Actualizar la reserva
            int resultado = mReservaViewModel.update(reserva);
            
            if (resultado > 0) {
                // Eliminar quads antiguos
                mReservaViewModel.eliminarTodosQuadsDeReserva(id);
                
                // Insertar nuevos quads
                ArrayList<String> matriculas = extras.getStringArrayList("matriculas_quads");
                ArrayList<Integer> numCascos = extras.getIntegerArrayList("num_cascos");
                
                if (matriculas != null && numCascos != null && !matriculas.isEmpty()) {
                    for (int i = 0; i < matriculas.size(); i++) {
                        mReservaViewModel.agregarQuadAReserva(id, matriculas.get(i), numCascos.get(i));
                    }
                }
            }
        }
    });

    ActivityResultLauncher<Intent> mStartDeleteReserva = registerForActivityResult(
            new StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    boolean confirmed = result.getData().getBooleanExtra(ReservaDeleteActivity.EXTRA_CONFIRMED, false);
                    Reserva reserva = (Reserva) result.getData().getSerializableExtra(ReservaDeleteActivity.EXTRA_RESERVA);
                    
                    if (confirmed && reserva != null) {
            mReservaViewModel.delete(reserva);
                        Toast.makeText(ReservasActivity.this, "Reserva eliminada", Toast.LENGTH_SHORT).show();
                    }
        }
    });

    @Override
    public void onEditReserva(Reserva reserva) {
        if (reserva != null) {
            Intent intent = new Intent(this, ReservaEdit.class);
            intent.putExtra(ReservaEdit.RESERVA_ID, reserva.getId());
            intent.putExtra(ReservaEdit.RESERVA_NOMBRECLIENTE, reserva.getNombreCliente());
            intent.putExtra(ReservaEdit.RESERVA_TELEFONOCLIENTE, reserva.getTelefonoCliente());

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            intent.putExtra(ReservaEdit.RESERVA_FECHARECOGIDA, sdf.format(reserva.getFechaRecogida()));
            intent.putExtra(ReservaEdit.RESERVA_FECHADEVOLUCION, sdf.format(reserva.getFechaDevolucion()));
            intent.putExtra(ReservaEdit.RESERVA_PRECIOTOTAL, String.valueOf(reserva.getPrecioTotal()));
            mStartUpdateReserva.launch(intent);
        }
    }

    @Override
    public void onDeleteReserva(Reserva reserva) {
        Intent intent = new Intent(this, ReservaDeleteActivity.class);
        intent.putExtra(ReservaDeleteActivity.EXTRA_RESERVA, reserva);
        mStartDeleteReserva.launch(intent);
    }


    @Override
    public void onSendReserva(Reserva reserva) {
        String telefonoCliente = reserva.getTelefonoFormateado();

        if (telefonoCliente == null || telefonoCliente.trim().isEmpty()) {
            Toast.makeText(this, "No hay número de teléfono disponible",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Mostrar diálogo para elegir método de envío
        String[] opciones = {getString(R.string.whatsapp), getString(R.string.sms)};
        
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.elegir_metodo_envio)
                .setItems(opciones, (dialog, which) -> {
                    String metodo = (which == 0) ? "WhatsApp" : "SMS";
                    enviarReservaConMetodo(reserva, metodo);
                })
                .setNegativeButton(R.string.cancelar, null)
                .show();
    }

    private void enviarReservaConMetodo(Reserva reserva, String metodo) {
        SendAbstraction sendAbstraction = new SendAbstractionImpl(this, metodo);
        String mensaje = formatearMensajeReserva(reserva);
        String telefonoCliente = reserva.getTelefonoFormateado();
        sendAbstraction.send(telefonoCliente, mensaje);
    }

    private String formatearMensajeReserva(Reserva reserva) {
        return String.format(
                "RESERVA CONFIRMADA - Reserva de quads\n\n" +
                        "Cliente: %s\n" +
                        "Teléfono: %s\n" +
                        "Fechas: %s\n" +
                        "Resumen: %s\n" +
                        "Total: %.2f€\n\n" +
                        "¡Gracias por tu reserva!",
                reserva.getNombreCliente(),
                reserva.getTelefonoCliente(),
                reserva.getFechasFormateadas(),
                reserva.getResumenQuads(),
                reserva.getPrecioTotal()
        );
    }
}