package es.unizar.eina.T221_quads.ui;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;

import es.unizar.eina.T221_quads.database.Reserva;

public class ReservasListAdapter extends ListAdapter<Reserva, ReservaViewHolder> {
    private int position;
    private final OnReservaActionListener mListener;
    private final ViewModelStoreOwner mViewModelStoreOwner;
    private final LifecycleOwner mLifecycleOwner;

    public interface OnReservaActionListener {
        void onEditReserva(Reserva reserva);
        void onDeleteReserva(Reserva reserva);
        void onSendReserva(Reserva reserva);
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public ReservasListAdapter(@NonNull DiffUtil.ItemCallback<Reserva> diffCallback, 
                               OnReservaActionListener listener,
                               ViewModelStoreOwner viewModelStoreOwner,
                               LifecycleOwner lifecycleOwner) {
        super(diffCallback);
        mListener = listener;
        mViewModelStoreOwner = viewModelStoreOwner;
        mLifecycleOwner = lifecycleOwner;
    }

    @NonNull
    @Override
    public ReservaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return ReservaViewHolder.create(parent);
    }

    public Reserva getCurrent() {
        return getItem(getPosition());
    }

    @Override
    public void onBindViewHolder(ReservaViewHolder holder, int position) {
        Reserva current = getItem(position);
        holder.bind(current, mViewModelStoreOwner, mLifecycleOwner);

        // Configurar botón editar
        holder.getButtonEdit().setOnClickListener(v -> {
            if (mListener != null) mListener.onEditReserva(current);
        });

        // Configurar botón eliminar
        holder.getButtonDelete().setOnClickListener(v -> {
            if (mListener != null) mListener.onDeleteReserva(current);
        });

        // Configurar botón enviar
        holder.getButtonSend().setOnClickListener(v -> {
            if (mListener != null) mListener.onSendReserva(current);
        });
    }

    static class ReservaDiff extends DiffUtil.ItemCallback<Reserva> {
        @Override
        public boolean areItemsTheSame(@NonNull Reserva oldItem, @NonNull Reserva newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Reserva oldItem, @NonNull Reserva newItem) {
            return oldItem.getNombreCliente().equals(newItem.getNombreCliente()) &&
                    oldItem.getTelefonoCliente().equals(newItem.getTelefonoCliente()) &&
                    oldItem.getFechaRecogida().equals(newItem.getFechaRecogida()) &&
                    oldItem.getFechaDevolucion().equals(newItem.getFechaDevolucion()) &&
                    oldItem.getPrecioTotal() == newItem.getPrecioTotal();
        }
    }
}