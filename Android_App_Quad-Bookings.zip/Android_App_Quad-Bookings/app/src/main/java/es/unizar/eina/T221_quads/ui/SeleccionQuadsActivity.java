package es.unizar.eina.T221_quads.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import es.unizar.eina.T221_quads.R;
import es.unizar.eina.T221_quads.database.Quad;

public class SeleccionQuadsActivity extends AppCompatActivity implements SeleccionQuadsAdapter.OnQuadClickListener {

    public static final String QUAD_MATRICULA = "matricula";
    public static final String QUAD_TIPO = "tipo";
    public static final String QUAD_PRECIO = "precio";

    private SeleccionQuadsAdapter mAdapter;
    private List<String> mMatriculasSeleccionadas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seleccion_quads);

        // Obtener quads ya seleccionados (para evitar duplicados)
        mMatriculasSeleccionadas = getIntent().getStringArrayListExtra("matriculas_seleccionadas");
        if (mMatriculasSeleccionadas == null) mMatriculasSeleccionadas = new ArrayList<>();

        // Obtener fechas y ID de reserva a excluir
        Intent intent = getIntent();
        long fechaRecogidaMillis = intent.getLongExtra("fecha_recogida", -1);
        long fechaDevolucionMillis = intent.getLongExtra("fecha_devolucion", -1);
        int excluirReservaId = intent.getIntExtra("excluir_reserva_id", -1);

        QuadViewModel mQuadViewModel = new ViewModelProvider(this).get(QuadViewModel.class);
        ReservaViewModel mReservaViewModel = new ViewModelProvider(this).get(ReservaViewModel.class);

        RecyclerView recyclerView = findViewById(R.id.recyclerViewQuads);
        ImageButton mBackButton = findViewById(R.id.button_back);

        mAdapter = new SeleccionQuadsAdapter(new SeleccionQuadsAdapter.QuadDiff(), this);
        recyclerView.setAdapter(mAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Cargar quads disponibles
        if (fechaRecogidaMillis > 0 && fechaDevolucionMillis > 0) {
            // Filtrar por fechas (quads disponibles en el rango)
            Date fechaRecogida = new Date(fechaRecogidaMillis);
            Date fechaDevolucion = new Date(fechaDevolucionMillis);
            
            mReservaViewModel.getQuadsDisponibles(fechaRecogida, fechaDevolucion, excluirReservaId)
                    .observe(this, quads -> {
                        // Filtrar quads ya seleccionados
                        List<Quad> quadsFiltrados = new ArrayList<>();
                        for (Quad quad : quads) {
                            if (!mMatriculasSeleccionadas.contains(quad.getMatricula())) {
                                quadsFiltrados.add(quad);
                            }
                        }
                        mAdapter.submitList(quadsFiltrados);
                    });
        } else {
            // Si no hay fechas, mostrar todos los quads (comportamiento anterior)
            mQuadViewModel.getQuadsByMatriculaAsc().observe(this, quads -> {
                // Filtrar quads ya seleccionados
                List<Quad> quadsFiltrados = new ArrayList<>();
                for (Quad quad : quads) {
                    if (!mMatriculasSeleccionadas.contains(quad.getMatricula())) {
                        quadsFiltrados.add(quad);
                    }
                }
                mAdapter.submitList(quadsFiltrados);
            });
        }

        mBackButton.setOnClickListener(v -> finish());
    }

    @Override
    public void onQuadClick(Quad quad) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra(SeleccionQuadsActivity.QUAD_MATRICULA, quad.getMatricula());
        resultIntent.putExtra(SeleccionQuadsActivity.QUAD_TIPO, quad.getTipo());
        resultIntent.putExtra(SeleccionQuadsActivity.QUAD_PRECIO, quad.getPrecio());
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}