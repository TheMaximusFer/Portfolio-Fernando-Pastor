package es.unizar.eina.T221_quads.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;

import es.unizar.eina.T221_quads.R;
import es.unizar.eina.T221_quads.database.Quad;

public class SeleccionQuadsAdapter extends ListAdapter<Quad, QuadViewHolder> {
    private final OnQuadClickListener mListener;

    public interface OnQuadClickListener {
        void onQuadClick(Quad quad);
    }

    public SeleccionQuadsAdapter(@NonNull DiffUtil.ItemCallback<Quad> diffCallback,
                                 OnQuadClickListener listener) {
        super(diffCallback);
        this.mListener = listener;
    }

    @NonNull
    @Override
    public QuadViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_quad_seleccionable, parent, false);
        return new QuadViewHolder(view);
    }

    @Override
    public void onBindViewHolder(QuadViewHolder holder, int position) {
        Quad current = getItem(position);
        holder.bind(current);

        holder.itemView.setOnClickListener(v -> {
            if (mListener != null) mListener.onQuadClick(current);
        });
    }

    static class QuadDiff extends DiffUtil.ItemCallback<Quad> {

        @Override
        public boolean areItemsTheSame(@NonNull Quad oldItem, @NonNull Quad newItem) {
            return oldItem.getMatricula().equals(newItem.getMatricula());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Quad oldItem, @NonNull Quad newItem) {
            return oldItem.getMatricula().equals(newItem.getMatricula()) &&
                    oldItem.getTipo().equals(newItem.getTipo()) &&
                    oldItem.getPrecio() == newItem.getPrecio();
        }
    }
}
